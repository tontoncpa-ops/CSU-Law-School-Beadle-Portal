import { BeadleStoreState } from '../types';
import { formatDateToISO, getCurrentWednesdayISO } from '../utils/storage';

function getPreviousWednesdayISO(currentWedISO: string, weeksAgo: number): string {
  const [y, m, d] = currentWedISO.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  dt.setDate(dt.getDate() - weeksAgo * 7);
  return formatDateToISO(dt);
}

export function createInitialSeedState(): BeadleStoreState {
  const currentWed = getCurrentWednesdayISO();
  const prevWed = getPreviousWednesdayISO(currentWed, 1);
  const twoWeeksAgoWed = getPreviousWednesdayISO(currentWed, 2);

  const students = [
    { id: 'stu-1', studentNo: '2024-0104', fullName: 'Alvarez, Gabriel M.' },
    { id: 'stu-2', studentNo: '2024-0112', fullName: 'Bautista, Maria Clarissa R.' },
    { id: 'stu-3', studentNo: '2024-0129', fullName: 'Delos Santos, Paolo J.' },
    { id: 'stu-4', studentNo: '2024-0137', fullName: 'Mendoza, Katrina L.' },
    { id: 'stu-5', studentNo: '2024-0145', fullName: 'Villanueva, Rafael C.' },
  ];

  const meetings = [
    {
      id: 'mtg-seed-current',
      date: currentWed,
      timeRange: '6:00 PM - 8:00 PM PHT',
      modality: 'In-Person' as const,
      professorAttendance: {
        status: 'Present' as const,
        remarks: 'Conducted graded Socratic recitation on R.A. 7160 Book I, Secs. 1–24.',
      },
      studentAttendance: {
        'stu-1': { status: 'Present' as const, remarks: '' },
        'stu-2': { status: 'Present' as const, remarks: 'Class Beadle; submitted weekly attendance sheet.' },
        'stu-3': { status: 'Absent' as const, remarks: 'No prior notice sent.' },
        'stu-4': { status: 'Present' as const, remarks: 'Arrived 15 mins after roll call due to transit delay.' },
        'stu-5': { status: 'Excused' as const, remarks: 'Submitted approved excuse letter for BAR prep seminar.' },
      },
      topicsDiscussed:
        '1. Constitutional Foundations of Local Autonomy (1987 Constitution, Art. X, Secs. 1–14).\n' +
        '2. Distinction between Decentralization of Administration and Decentralization of Power (Limbona v. Mangelin, G.R. No. 80391).\n' +
        '3. Creation, Conversion, Division, Merger, and Abolition of LGUs under R.A. 7160, Secs. 6–10.\n' +
        '4. National Tax Allotment (NTA) doctrine under Mandanas-Garcia v. Executive Secretary (G.R. No. 199802).',
      screenshots: [],
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'mtg-seed-prev',
      date: prevWed,
      timeRange: '6:00 PM - 8:00 PM PHT',
      modality: 'In-Person' as const,
      professorAttendance: {
        status: 'Present' as const,
        remarks: 'Delivered lecture on LGU corporate powers and police power.',
      },
      studentAttendance: {
        'stu-1': { status: 'Present' as const, remarks: '' },
        'stu-2': { status: 'Present' as const, remarks: '' },
        'stu-3': { status: 'Absent' as const, remarks: 'Work travel without Dean excuse approval.' },
        'stu-4': { status: 'Absent' as const, remarks: 'Called in sick at 4 PM; medical certificate pending.' },
        'stu-5': { status: 'Excused' as const, remarks: 'Excused by Academic Dean for Moot Court regional briefing.' },
      },
      topicsDiscussed:
        '1. Corporate Powers of Local Government Units (R.A. 7160, Sec. 22).\n' +
        '2. General Welfare Clause & Police Power Delegated to LGUs (Sec. 16).\n' +
        '3. Requisites for Valid Municipal Ordinances (Tatel v. Municipality of Virac).',
      screenshots: [],
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'mtg-seed-earlier',
      date: twoWeeksAgoWed,
      timeRange: '6:00 PM - 8:00 PM PHT',
      modality: 'In-Person' as const,
      professorAttendance: {
        status: 'Present' as const,
        remarks: 'Course orientation and overview of Book I of R.A. 7160.',
      },
      studentAttendance: {
        'stu-1': { status: 'Present' as const, remarks: '' },
        'stu-2': { status: 'Present' as const, remarks: '' },
        'stu-3': { status: 'Absent' as const, remarks: 'Missed orientation session.' },
        'stu-4': { status: 'Absent' as const, remarks: 'Personal errand.' },
        'stu-5': { status: 'Present' as const, remarks: '' },
      },
      topicsDiscussed:
        '1. Course Orientation & Academic Policies for Laws on Local Government.\n' +
        '2. Historical Evolution of Local Government Systems in the Philippines.\n' +
        '3. General Principles and Rules of Interpretation under R.A. 7160, Secs. 1–5.',
      screenshots: [],
      updatedAt: new Date().toISOString(),
    },
  ];

  return {
    config: {
      university: 'Cagayan State University - Carig Campus',
      college: 'College of Law',
      recipientOffice: 'Office of the Academic Dean - College of Law',
      courseTitle: 'Laws on Local Government',
      units: '2 Units',
      scheduleLabel: 'Wednesdays, 6:00 PM – 8:00 PM PHT',
      professorName: 'Atty. Roberto V. Domingo, LL.M.',
      beadleName: 'Maria Clarissa R. Bautista',
      semesterMaxUnexcused: 3,
    },
    students,
    meetings,
  };
}
