export type StudentAttendanceStatus = 'Present' | 'Absent' | 'Excused';

export type ProfessorAttendanceStatus = 'Present' | 'Late' | 'Absent' | 'Excused';

export const STUDENT_ATTENDANCE_STATUSES: StudentAttendanceStatus[] = [
  'Present',
  'Absent',
  'Excused',
];

export const PROFESSOR_ATTENDANCE_STATUSES: ProfessorAttendanceStatus[] = [
  'Present',
  'Late',
  'Absent',
  'Excused',
];

export interface StudentAttendanceRecord {
  status: StudentAttendanceStatus;
  remarks: string;
}

export interface ProfessorAttendanceRecord {
  status: ProfessorAttendanceStatus;
  remarks: string;
}

export interface Student {
  id: string;
  studentNo: string;
  fullName: string;
}

export interface ClassScreenshot {
  id: string;
  name: string;
  dataUrl: string;
  caption: string;
  uploadedAt: string;
}

export type SessionModality = 'In-Person' | 'Online' | 'Hybrid';

export interface MeetingRecord {
  id: string;
  date: string; // YYYY-MM-DD
  timeRange: string; // e.g. "6:00 PM - 8:00 PM PHT"
  modality: SessionModality;
  professorAttendance: ProfessorAttendanceRecord;
  studentAttendance: Record<string, StudentAttendanceRecord>;
  topicsDiscussed: string;
  screenshots: ClassScreenshot[];
  updatedAt: string;
}

export interface CourseConfig {
  university: string;
  college: string;
  recipientOffice: string;
  courseTitle: string;
  units: string;
  scheduleLabel: string;
  professorName: string;
  beadleName: string;
  semesterMaxUnexcused: number;
}

export interface BeadleStoreState {
  config: CourseConfig;
  students: Student[];
  meetings: MeetingRecord[];
}
