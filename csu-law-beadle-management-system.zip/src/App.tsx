import React, { useEffect, useMemo, useState } from 'react';
import {
  BookOpen,
  Calendar,
  ChevronRight,
  FileText,
  Menu,
  Plus,
  Scale,
  Trash2,
  Users,
  X,
  Check,
  AlertCircle,
  SlidersHorizontal,
} from 'lucide-react';
import {
  BeadleStoreState,
  CourseConfig,
  MeetingRecord,
  ProfessorAttendanceRecord,
  SessionModality,
  Student,
  StudentAttendanceRecord,
} from './types';
import {
  computeSemesterAbsenceMap,
  createBlankMeeting,
  formatDateToISO,
  formatReadableDate,
  formatShortDate,
  getCurrentWednesdayISO,
  getSemesterFromISO,
  loadStore,
  saveStore,
} from './utils/storage';
import { createInitialSeedState } from './data/seedData';
import { AttendanceTracker } from './components/AttendanceTracker';
import { ClassDocumentation } from './components/ClassDocumentation';
import { MonthlyReport } from './components/MonthlyReport';
import { RosterSettings } from './components/RosterSettings';

type ActiveTab = 'session' | 'report' | 'roster';

function getFirstWednesdayOfMonthISO(year: number, month: number): string {
  const d = new Date(year, month - 1, 1);
  while (d.getDay() !== 3) {
    d.setDate(d.getDate() + 1);
  }
  return formatDateToISO(d);
}

export default function App() {
  const [store, setStore] = useState<BeadleStoreState>(() =>
    loadStore(createInitialSeedState())
  );

  const sortedMeetings = useMemo(() => {
    return [...store.meetings].sort((a, b) => b.date.localeCompare(a.date));
  }, [store.meetings]);

  const [activeTab, setActiveTab] = useState<ActiveTab>('session');
  const [selectedMeetingId, setSelectedMeetingId] = useState<string>(() => {
    const initial = loadStore(createInitialSeedState());
    const sorted = [...initial.meetings].sort((a, b) =>
      b.date.localeCompare(a.date)
    );
    return sorted[0]?.id || '';
  });

  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [storageError, setStorageError] = useState<string | null>(null);
  const [saveTick, setSaveTick] = useState<number>(0);

  useEffect(() => {
    const result = saveStore(store);
    if (!result.ok) {
      setStorageError(result.error || 'Could not save to browser Local Storage.');
    } else {
      setStorageError(null);
      setSaveTick((t) => t + 1);
    }
  }, [store]);

  const activeMeeting = useMemo(() => {
    return (
      store.meetings.find((m) => m.id === selectedMeetingId) ||
      sortedMeetings[0] ||
      null
    );
  }, [store.meetings, selectedMeetingId, sortedMeetings]);

  const activeSemester = useMemo(() => {
    const refDate = activeMeeting?.date || getCurrentWednesdayISO();
    return getSemesterFromISO(refDate);
  }, [activeMeeting]);

  const semesterAbsenceMap = useMemo(() => {
    return computeSemesterAbsenceMap(
      store.meetings,
      store.students,
      activeSemester.key
    );
  }, [store.meetings, store.students, activeSemester.key]);

  const handleCreateNewMeeting = (dateOverride?: string) => {
    const blank = createBlankMeeting(
      store.students,
      dateOverride || getCurrentWednesdayISO()
    );
    setStore((prev) => ({
      ...prev,
      meetings: [blank, ...prev.meetings],
    }));
    setSelectedMeetingId(blank.id);
    setActiveTab('session');
    setMobileNavOpen(false);
    setConfirmDeleteId(null);
  };

  const handleCreateMeetingForMonth = (year: number, month: number) => {
    const targetWed = getFirstWednesdayOfMonthISO(year, month);
    handleCreateNewMeeting(targetWed);
  };

  const updateActiveMeeting = (
    updater: (meeting: MeetingRecord) => MeetingRecord
  ) => {
    if (!activeMeeting) return;
    setStore((prev) => ({
      ...prev,
      meetings: prev.meetings.map((m) =>
        m.id === activeMeeting.id
          ? { ...updater(m), updatedAt: new Date().toISOString() }
          : m
      ),
    }));
  };

  const handleDeleteMeeting = (meetingId: string) => {
    const remaining = store.meetings.filter((m) => m.id !== meetingId);
    setStore((prev) => ({
      ...prev,
      meetings: remaining,
    }));
    const nextSorted = [...remaining].sort((a, b) =>
      b.date.localeCompare(a.date)
    );
    setSelectedMeetingId(nextSorted[0]?.id || '');
    setConfirmDeleteId(null);
  };

  const handleProfessorAttendanceChange = (next: ProfessorAttendanceRecord) => {
    updateActiveMeeting((m) => ({
      ...m,
      professorAttendance: next,
    }));
  };

  const handleStudentAttendanceChange = (
    studentId: string,
    next: StudentAttendanceRecord
  ) => {
    updateActiveMeeting((m) => ({
      ...m,
      studentAttendance: {
        ...m.studentAttendance,
        [studentId]: next,
      },
    }));
  };

  const handleMarkAllPresent = () => {
    updateActiveMeeting((m) => {
      const nextMap: Record<string, StudentAttendanceRecord> = {
        ...m.studentAttendance,
      };
      for (const s of store.students) {
        const existing = nextMap[s.id];
        nextMap[s.id] = {
          status: 'Present',
          remarks: existing?.remarks || '',
        };
      }
      return {
        ...m,
        studentAttendance: nextMap,
      };
    });
  };

  const handleConfigChange = (config: CourseConfig) => {
    setStore((prev) => ({ ...prev, config }));
  };

  const handleStudentsChange = (students: Student[]) => {
    setStore((prev) => ({ ...prev, students }));
  };

  const handleResetDemoData = () => {
    const fresh = createInitialSeedState();
    setStore(fresh);
    setSelectedMeetingId(fresh.meetings[0]?.id || '');
  };

  const navItems: Array<{ id: ActiveTab; label: string; icon: React.ElementType }> = [
    { id: 'session', label: 'Session Log', icon: BookOpen },
    { id: 'report', label: 'Monthly Report', icon: FileText },
    { id: 'roster', label: 'Class Setup & Roster', icon: Users },
  ];

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-navy-900 text-slate-100">
      <div className="px-5 py-5 border-b border-white/10">
        <div className="flex items-center gap-2.5">
          <Scale className="w-5 h-5 text-slate-200 shrink-0" aria-hidden="true" />
          <span className="text-sm font-bold tracking-tight text-white">
            CSU Law Beadle
          </span>
        </div>
        <div className="mt-2 text-xs text-slate-200 font-medium leading-snug">
          {store.config.courseTitle}
          {store.config.units ? ` (${store.config.units})` : ''}
        </div>
        <div className="text-[11px] text-slate-400 mt-0.5">
          {store.config.scheduleLabel}
        </div>
        <button
          type="button"
          onClick={() => {
            setActiveTab('roster');
            setMobileNavOpen(false);
          }}
          className="mt-2.5 inline-flex items-center gap-1.5 text-[11px] text-slate-300 hover:text-white underline underline-offset-2"
        >
          <SlidersHorizontal className="w-3 h-3" aria-hidden="true" />
          <span>Edit Class Specifications</span>
        </button>
      </div>

      <nav aria-label="Workspace navigation" className="px-3 py-4 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                setActiveTab(item.id);
                setMobileNavOpen(false);
              }}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                active
                  ? 'bg-white/12 text-white'
                  : 'text-slate-300 hover:bg-white/6 hover:text-white'
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="px-3 pt-3 pb-2 border-t border-white/10 flex items-center justify-between">
        <span className="px-2 text-xs font-semibold text-slate-300">
          Logged Sessions ({sortedMeetings.length})
        </span>
        <button
          type="button"
          onClick={() => handleCreateNewMeeting()}
          title="Create new session"
          className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded transition-colors"
          aria-label="Create new meeting session"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-3 pb-4 space-y-1">
        {sortedMeetings.length === 0 ? (
          <div className="px-2 py-4 text-xs text-slate-400">
            No sessions logged yet.
          </div>
        ) : (
          sortedMeetings.map((mtg) => {
            const isSelected =
              activeTab === 'session' && activeMeeting?.id === mtg.id;
            return (
              <button
                key={mtg.id}
                type="button"
                onClick={() => {
                  setSelectedMeetingId(mtg.id);
                  setActiveTab('session');
                  setMobileNavOpen(false);
                  setConfirmDeleteId(null);
                }}
                className={`w-full text-left px-3 py-2.5 rounded-md transition-colors flex items-center justify-between gap-2 ${
                  isSelected
                    ? 'bg-navy-700 text-white'
                    : 'text-slate-300 hover:bg-white/6 hover:text-white'
                }`}
              >
                <div className="min-w-0">
                  <div className="text-xs font-medium font-mono tabular-nums truncate">
                    {formatShortDate(mtg.date)}
                  </div>
                  <div className="text-[11px] text-slate-400 truncate">
                    Prof: {mtg.professorAttendance.status} · {mtg.modality}
                  </div>
                </div>
                <ChevronRight
                  className="w-3.5 h-3.5 text-slate-400 shrink-0"
                  aria-hidden="true"
                />
              </button>
            );
          })
        )}
      </div>

      <div className="px-5 py-3 border-t border-white/10 text-[11px] text-slate-400 leading-snug">
        {store.config.university}
      </div>
    </div>
  );

  const pageTitle =
    activeTab === 'session'
      ? 'Class Session Log'
      : activeTab === 'report'
      ? 'Monthly Dean’s Report'
      : 'Class Specifications & Student Roster';

  return (
    <div className="min-h-screen flex bg-slate-50 text-slate-900">
      <aside className="no-print hidden lg:block w-64 shrink-0 border-r border-slate-200 sticky top-0 h-screen">
        <SidebarContent />
      </aside>

      {mobileNavOpen && (
        <div
          className="no-print fixed inset-0 z-50 lg:hidden flex"
          role="dialog"
          aria-modal="true"
          aria-label="Navigation menu"
        >
          <div
            className="fixed inset-0 bg-slate-950/60"
            onClick={() => setMobileNavOpen(false)}
          />
          <div className="relative w-72 max-w-[85vw] h-full z-10 shadow-xl">
            <button
              type="button"
              onClick={() => setMobileNavOpen(false)}
              aria-label="Close navigation menu"
              className="absolute top-4 right-3 p-1.5 text-slate-300 hover:text-white rounded-md"
            >
              <X className="w-5 h-5" />
            </button>
            <SidebarContent />
          </div>
        </div>
      )}

      <div className="flex-1 min-w-0 flex flex-col">
        <header className="no-print sticky top-0 z-30 bg-white border-b border-slate-200 px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileNavOpen(true)}
              aria-label="Open navigation menu"
              className="lg:hidden p-2 -ml-2 text-slate-700 hover:text-navy-900 rounded-md hover:bg-slate-100"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 min-w-0 text-sm">
              <span className="hidden sm:inline text-slate-500 truncate">
                {store.config.courseTitle}
              </span>
              <span className="hidden sm:inline text-slate-300" aria-hidden="true">
                /
              </span>
              <h1 className="font-semibold text-navy-900 truncate">
                {pageTitle}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {saveTick > 0 && !storageError && (
              <span className="hidden md:inline-flex items-center gap-1 text-xs text-slate-500">
                <Check className="w-3.5 h-3.5 text-emerald-700" aria-hidden="true" />
                <span>Saved in browser</span>
              </span>
            )}
            <button
              type="button"
              onClick={() => handleCreateNewMeeting()}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-navy-900 rounded-md hover:bg-navy-800 transition-colors whitespace-nowrap shrink-0"
            >
              <Plus className="w-4 h-4" aria-hidden="true" />
              <span>New Meeting</span>
            </button>
          </div>
        </header>

        <div className="no-print lg:hidden bg-white border-b border-slate-200 px-4 py-2 flex items-center gap-1 overflow-x-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-navy-900 text-white'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <Icon className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

        {storageError && (
          <div
            role="alert"
            className="no-print mx-4 sm:mx-6 lg:mx-8 mt-4 px-4 py-3 bg-red-50 border border-red-200 rounded-md flex items-center gap-2.5 text-xs text-red-800"
          >
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{storageError}</span>
          </div>
        )}

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-5xl w-full mx-auto">
          {activeTab === 'session' && (
            <div className="space-y-6">
              {!activeMeeting ? (
                <div className="bg-white border border-slate-200 rounded-lg px-6 py-16 text-center">
                  <Calendar
                    className="w-10 h-10 text-slate-400 mx-auto mb-3"
                    aria-hidden="true"
                  />
                  <h2 className="text-base font-semibold text-slate-900">
                    No class meeting selected
                  </h2>
                  <p className="text-sm text-slate-500 mt-1 max-w-md mx-auto">
                    Create a new session entry to log professor and student attendance, topics discussed, and lecture screenshots.
                  </p>
                  <button
                    type="button"
                    onClick={() => handleCreateNewMeeting()}
                    className="mt-5 inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-navy-900 rounded-md hover:bg-navy-800 transition-colors"
                  >
                    <Plus className="w-4 h-4" aria-hidden="true" />
                    <span>Create Meeting</span>
                  </button>
                </div>
              ) : (
                <>
                  {sortedMeetings.length > 1 && (
                    <div className="lg:hidden bg-white border border-slate-200 rounded-lg p-3.5 flex items-center justify-between gap-3">
                      <label
                        htmlFor="mobile-session-select"
                        className="text-xs font-medium text-slate-600 shrink-0"
                      >
                        Session:
                      </label>
                      <select
                        id="mobile-session-select"
                        value={activeMeeting.id}
                        onChange={(e) => {
                          setSelectedMeetingId(e.target.value);
                          setConfirmDeleteId(null);
                        }}
                        className="flex-1 px-3 py-1.5 text-xs font-medium text-slate-900 bg-slate-50 border border-slate-200 rounded-md"
                      >
                        {sortedMeetings.map((m) => (
                          <option key={m.id} value={m.id}>
                            {formatReadableDate(m.date)} ({m.modality})
                          </option>
                        ))}
                      </select>
                    </div>
                  )}

                  <section
                    aria-labelledby="meeting-setup-heading"
                    className="bg-white border border-slate-200 rounded-lg"
                  >
                    <div className="px-5 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <h2
                          id="meeting-setup-heading"
                          className="text-base font-semibold text-navy-900"
                        >
                          Meeting Setup
                        </h2>
                        <p className="text-xs text-slate-500 mt-0.5">
                          {formatReadableDate(activeMeeting.date)} ·{' '}
                          <span className="font-mono tabular-nums">
                            {activeMeeting.timeRange}
                          </span>{' '}
                          · {activeSemester.label}
                        </p>
                      </div>

                      {confirmDeleteId === activeMeeting.id ? (
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-red-700 font-medium">
                            Delete this session?
                          </span>
                          <button
                            type="button"
                            onClick={() => handleDeleteMeeting(activeMeeting.id)}
                            className="px-2.5 py-1.5 text-xs font-semibold text-white bg-red-700 hover:bg-red-800 rounded transition-colors"
                          >
                            Delete
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteId(null)}
                            className="px-2.5 py-1.5 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded transition-colors"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(activeMeeting.id)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-red-700 hover:bg-red-50 border border-slate-200 rounded-md transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                          <span>Delete Session</span>
                        </button>
                      )}
                    </div>

                    <div className="p-5 grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div>
                        <label
                          htmlFor="meeting-date-input"
                          className="block text-xs font-medium text-slate-600 mb-1.5"
                        >
                          Meeting Date
                        </label>
                        <input
                          id="meeting-date-input"
                          type="date"
                          value={activeMeeting.date}
                          onChange={(e) =>
                            updateActiveMeeting((m) => ({
                              ...m,
                              date: e.target.value,
                            }))
                          }
                          className="w-full px-3 py-2 text-sm font-mono tabular-nums text-slate-900 bg-slate-50 border border-slate-200 rounded-md focus:bg-white focus:outline-none focus:border-navy-700 focus:ring-1 focus:ring-navy-700"
                        />
                      </div>

                      <div>
                        <label
                          htmlFor="meeting-time-input"
                          className="block text-xs font-medium text-slate-600 mb-1.5"
                        >
                          Class Time
                        </label>
                        <input
                          id="meeting-time-input"
                          type="text"
                          value={activeMeeting.timeRange}
                          onChange={(e) =>
                            updateActiveMeeting((m) => ({
                              ...m,
                              timeRange: e.target.value,
                            }))
                          }
                          placeholder="6:00 PM - 8:00 PM PHT"
                          className="w-full px-3 py-2 text-sm font-mono tabular-nums text-slate-900 bg-slate-50 border border-slate-200 rounded-md focus:bg-white focus:outline-none focus:border-navy-700 focus:ring-1 focus:ring-navy-700"
                        />
                      </div>

                      <div>
                        <label
                          htmlFor="meeting-modality-select"
                          className="block text-xs font-medium text-slate-600 mb-1.5"
                        >
                          Session Format
                        </label>
                        <select
                          id="meeting-modality-select"
                          value={activeMeeting.modality}
                          onChange={(e) =>
                            updateActiveMeeting((m) => ({
                              ...m,
                              modality: e.target.value as SessionModality,
                            }))
                          }
                          className="w-full px-3 py-2 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-md focus:bg-white focus:outline-none focus:border-navy-700 focus:ring-1 focus:ring-navy-700"
                        >
                          <option value="In-Person">In-Person</option>
                          <option value="Online">Online (Zoom)</option>
                          <option value="Hybrid">Hybrid</option>
                        </select>
                      </div>
                    </div>
                  </section>

                  <AttendanceTracker
                    courseTitle={store.config.courseTitle}
                    units={store.config.units}
                    professorName={store.config.professorName}
                    professorAttendance={activeMeeting.professorAttendance}
                    onProfessorChange={handleProfessorAttendanceChange}
                    students={store.students}
                    studentAttendance={activeMeeting.studentAttendance}
                    onStudentChange={handleStudentAttendanceChange}
                    onMarkAllPresent={handleMarkAllPresent}
                    onOpenRoster={() => setActiveTab('roster')}
                    semesterLabel={activeSemester.label}
                    semesterMaxUnexcused={store.config.semesterMaxUnexcused}
                    semesterAbsenceMap={semesterAbsenceMap}
                  />

                  <ClassDocumentation
                    topicsDiscussed={activeMeeting.topicsDiscussed}
                    onTopicsChange={(topicsDiscussed) =>
                      updateActiveMeeting((m) => ({ ...m, topicsDiscussed }))
                    }
                    screenshots={activeMeeting.screenshots}
                    onScreenshotsChange={(screenshots) =>
                      updateActiveMeeting((m) => ({ ...m, screenshots }))
                    }
                  />
                </>
              )}
            </div>
          )}

          {activeTab === 'report' && (
            <MonthlyReport
              config={store.config}
              students={store.students}
              meetings={store.meetings}
              onCreateMeetingForMonth={handleCreateMeetingForMonth}
            />
          )}

          {activeTab === 'roster' && (
            <RosterSettings
              config={store.config}
              onConfigChange={handleConfigChange}
              students={store.students}
              onStudentsChange={handleStudentsChange}
              onResetDemoData={handleResetDemoData}
            />
          )}
        </main>
      </div>
    </div>
  );
}
