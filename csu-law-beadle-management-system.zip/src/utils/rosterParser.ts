import * as XLSX from 'xlsx';
import mammoth from 'mammoth';
import * as pdfjsLib from 'pdfjs-dist';
import pdfWorkerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorkerUrl;

export interface ParsedStudentRow {
  tempId: string;
  studentNo: string;
  fullName: string;
  selected: boolean;
}

const STUDENT_ID_REGEX = /\b(\d{2,4}[-–]\d{3,6}|\d{6,10})\b/;

const HEADER_KEYWORDS = [
  'student no',
  'student number',
  'student id',
  'id no',
  'id number',
  'full name',
  'student name',
  'name of student',
  'last name',
  'first name',
  'surname',
  'remarks',
  'course',
  'subject',
  'cagayan state university',
  'college of law',
  'class list',
  'official roster',
  'semester',
  'page ',
  'total ',
  'prepared by',
];

function isNoiseOrHeaderLine(text: string): boolean {
  const lower = text.trim().toLowerCase();
  if (!lower || lower.length < 2) return true;
  if (/^[-=_*#.\s]+$/.test(lower)) return true;
  if (/^\d+\s*(students?|total|enrolled)/i.test(lower)) return true;
  return HEADER_KEYWORDS.some((kw) => lower === kw || lower.startsWith(kw + ' ') || lower.includes('student name') || lower.includes('id number'));
}

function cleanCell(val: unknown): string {
  if (val === null || val === undefined) return '';
  return String(val).replace(/\s+/g, ' ').trim();
}

function normalizeHeader(cell: string): string {
  return cell.toLowerCase().replace(/[^a-z0-9]/g, '');
}

/**
 * Parses a 2D table of strings (from Excel, CSV, or Word HTML table).
 */
function parseTableRows(rawRows: string[][]): ParsedStudentRow[] {
  const rows = rawRows
    .map((r) => r.map(cleanCell))
    .filter((r) => r.some((cell) => cell.length > 0));

  if (rows.length === 0) return [];

  // Look for a header row in the first 8 rows
  let headerIdx = -1;
  let idCol = -1;
  let fullNameCol = -1;
  let lastNameCol = -1;
  let firstNameCol = -1;
  let middleNameCol = -1;

  const searchLimit = Math.min(rows.length, 8);
  for (let i = 0; i < searchLimit; i++) {
    const row = rows[i];
    let foundHeaderSignal = false;
    row.forEach((cell, colIdx) => {
      const norm = normalizeHeader(cell);
      if (
        norm === 'studentno' ||
        norm === 'studentnumber' ||
        norm === 'studentid' ||
        norm === 'idno' ||
        norm === 'idnumber' ||
        norm === 'id'
      ) {
        idCol = colIdx;
        foundHeaderSignal = true;
      } else if (
        norm === 'fullname' ||
        norm === 'studentname' ||
        norm === 'nameofstudent' ||
        norm === 'name'
      ) {
        fullNameCol = colIdx;
        foundHeaderSignal = true;
      } else if (norm === 'lastname' || norm === 'surname' || norm === 'familyname') {
        lastNameCol = colIdx;
        foundHeaderSignal = true;
      } else if (norm === 'firstname' || norm === 'givenname') {
        firstNameCol = colIdx;
        foundHeaderSignal = true;
      } else if (norm === 'middlename' || norm === 'middleinitial' || norm === 'mi') {
        middleNameCol = colIdx;
      }
    });

    if (foundHeaderSignal && (fullNameCol !== -1 || (lastNameCol !== -1 && firstNameCol !== -1))) {
      headerIdx = i;
      break;
    }
    // Reset if not a real header row
    idCol = -1;
    fullNameCol = -1;
    lastNameCol = -1;
    firstNameCol = -1;
    middleNameCol = -1;
  }

  const parsed: ParsedStudentRow[] = [];

  if (headerIdx !== -1) {
    for (let i = headerIdx + 1; i < rows.length; i++) {
      const row = rows[i];
      let fullName = '';
      if (fullNameCol !== -1) {
        fullName = row[fullNameCol] || '';
      } else if (lastNameCol !== -1 && firstNameCol !== -1) {
        const last = row[lastNameCol] || '';
        const first = row[firstNameCol] || '';
        const mid = middleNameCol !== -1 ? row[middleNameCol] || '' : '';
        if (last || first) {
          fullName = `${last}${last && first ? ', ' : ''}${first}${mid ? ` ${mid}` : ''}`.trim();
        }
      }

      if (!fullName || isNoiseOrHeaderLine(fullName) || /^\d+$/.test(fullName)) {
        continue;
      }

      let studentNo = idCol !== -1 ? row[idCol] || '' : '';
      if (!studentNo) {
        const idMatch = fullName.match(STUDENT_ID_REGEX);
        if (idMatch) {
          studentNo = idMatch[1];
          fullName = fullName.replace(idMatch[0], '').replace(/^[\s\-–|,]+|[\s\-–|,]+$/g, '').trim();
        }
      }

      parsed.push({
        tempId: `imp-${Date.now()}-${parsed.length}`,
        studentNo: studentNo || `2026-${String(parsed.length + 101).padStart(4, '0')}`,
        fullName,
        selected: true,
      });
    }
    return parsed;
  }

  // Fallback when no explicit header row exists in the table
  for (const row of rows) {
    const joined = row.filter(Boolean).join(' | ');
    if (isNoiseOrHeaderLine(joined)) continue;

    // Heuristic: find cell matching student ID and longest non-numeric text cell as name
    let studentNo = '';
    const candidateNames: string[] = [];

    for (const cell of row) {
      if (!cell) continue;
      if (/^\d{1,3}\.?$/.test(cell)) continue; // skip row index like "1" or "1."
      if (!studentNo && STUDENT_ID_REGEX.test(cell)) {
        const m = cell.match(STUDENT_ID_REGEX);
        if (m && cell.replace(m[0], '').trim().length < 3) {
          studentNo = m[1];
          continue;
        }
      }
      if (/[a-zA-Z]{2,}/.test(cell) && !/@/.test(cell)) {
        candidateNames.push(cell);
      }
    }

    if (candidateNames.length === 0) continue;

    let fullName =
      candidateNames.length >= 2 &&
      !candidateNames[0].includes(',') &&
      candidateNames[0].split(' ').length === 1 &&
      candidateNames[1].split(' ').length <= 2
        ? `${candidateNames[0]}, ${candidateNames[1]}`
        : candidateNames[0];

    if (!studentNo) {
      const m = fullName.match(STUDENT_ID_REGEX);
      if (m) {
        studentNo = m[1];
        fullName = fullName.replace(m[0], '').replace(/^[\s\-–|,]+|[\s\-–|,]+$/g, '').trim();
      }
    }

    if (!fullName || isNoiseOrHeaderLine(fullName)) continue;

    parsed.push({
      tempId: `imp-${Date.now()}-${parsed.length}`,
      studentNo: studentNo || `2026-${String(parsed.length + 101).padStart(4, '0')}`,
      fullName,
      selected: true,
    });
  }

  return parsed;
}

/**
 * Parses unstructured text lines (from TXT, DOCX paragraphs, or PDF lines).
 */
function parseTextLines(lines: string[]): ParsedStudentRow[] {
  const parsed: ParsedStudentRow[] = [];

  for (const rawLine of lines) {
    let line = rawLine.replace(/\s+/g, ' ').trim();
    if (!line || isNoiseOrHeaderLine(line)) continue;

    // Remove leading numbering like "1.", "01)", "1 - "
    line = line.replace(/^\d{1,3}[.)]\s+/, '').trim();
    if (!line || !/[a-zA-Z]{2,}/.test(line)) continue;

    // Strip email addresses if included on the line
    line = line.replace(/\S+@\S+\.\S+/g, '').trim();

    let studentNo = '';
    const idMatch = line.match(STUDENT_ID_REGEX);
    if (idMatch) {
      studentNo = idMatch[1];
      line = line.replace(idMatch[0], ' ');
    }

    // Split on tabs or pipes if remaining
    line = line
      .replace(/\t+|\|/g, ' ')
      .replace(/^[\s\-–,;:|]+|[\s\-–,;:|]+$/g, '')
      .replace(/\s+/g, ' ')
      .trim();

    if (!line || line.length < 3 || isNoiseOrHeaderLine(line)) continue;
    // Skip lines that look like course/schedule metadata rather than person names
    if (/\b(pm|am|pht|units|monday|tuesday|wednesday|thursday|friday|saturday)\b/i.test(line)) {
      continue;
    }

    parsed.push({
      tempId: `imp-${Date.now()}-${parsed.length}`,
      studentNo: studentNo || `2026-${String(parsed.length + 101).padStart(4, '0')}`,
      fullName: line,
      selected: true,
    });
  }

  return parsed;
}

function parseDelimitedText(text: string): string[][] {
  const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);
  if (lines.length === 0) return [];
  const sample = lines[0];
  const delimiter = sample.includes('\t')
    ? '\t'
    : sample.includes(';') && !sample.includes(',')
    ? ';'
    : ',';

  return lines.map((line) => {
    const cells: string[] = [];
    let current = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') {
        if (inQuotes && line[i + 1] === '"') {
          current += '"';
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (ch === delimiter && !inQuotes) {
        cells.push(current.trim());
        current = '';
      } else {
        current += ch;
      }
    }
    cells.push(current.trim());
    return cells;
  });
}

async function parsePdfFile(buffer: ArrayBuffer): Promise<ParsedStudentRow[]> {
  const loadingTask = pdfjsLib.getDocument({ data: new Uint8Array(buffer) });
  const pdf = await loadingTask.promise;
  const allLines: string[] = [];

  for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
    const page = await pdf.getPage(pageNum);
    const content = await page.getTextContent();

    // Group text items by approximate Y coordinate so table rows stay on one line
    const lineBuckets: Array<{ y: number; items: Array<{ x: number; str: string }> }> = [];

    for (const item of content.items) {
      if (!('str' in item) || !item.str.trim()) continue;
      const transform = item.transform as number[];
      const x = transform[4] ?? 0;
      const y = transform[5] ?? 0;

      let bucket = lineBuckets.find((b) => Math.abs(b.y - y) <= 4);
      if (!bucket) {
        bucket = { y, items: [] };
        lineBuckets.push(bucket);
      }
      bucket.items.push({ x, str: item.str });
    }

    lineBuckets.sort((a, b) => b.y - a.y);
    for (const bucket of lineBuckets) {
      bucket.items.sort((a, b) => a.x - b.x);
      const lineText = bucket.items.map((it) => it.str).join(' ').trim();
      if (lineText) allLines.push(lineText);
    }
  }

  return parseTextLines(allLines);
}

async function parseDocxFile(buffer: ArrayBuffer): Promise<ParsedStudentRow[]> {
  const htmlRes = await mammoth.convertToHtml({ arrayBuffer: buffer });
  const doc = new DOMParser().parseFromString(htmlRes.value, 'text/html');
  const tables = Array.from(doc.querySelectorAll('table'));

  if (tables.length > 0) {
    const tableRows: string[][] = [];
    for (const table of tables) {
      const trs = Array.from(table.querySelectorAll('tr'));
      for (const tr of trs) {
        const cells = Array.from(tr.querySelectorAll('th, td')).map(
          (td) => td.textContent?.replace(/\s+/g, ' ').trim() || ''
        );
        if (cells.some(Boolean)) {
          tableRows.push(cells);
        }
      }
    }
    const fromTable = parseTableRows(tableRows);
    if (fromTable.length > 0) return fromTable;
  }

  const textRes = await mammoth.extractRawText({ arrayBuffer: buffer });
  const lines = textRes.value.split(/\r?\n/);
  return parseTextLines(lines);
}

export async function parseRosterDocument(file: File): Promise<ParsedStudentRow[]> {
  const ext = file.name.split('.').pop()?.toLowerCase() || '';

  if (ext === 'xlsx' || ext === 'xls') {
    const buffer = await file.arrayBuffer();
    const workbook = XLSX.read(buffer, { type: 'array' });
    const firstSheetName = workbook.SheetNames[0];
    if (!firstSheetName) return [];
    const sheet = workbook.Sheets[firstSheetName];
    const rows = XLSX.utils.sheet_to_json<unknown[]>(sheet, {
      header: 1,
      defval: '',
    });
    const stringRows = rows.map((r) =>
      Array.isArray(r) ? r.map(cleanCell) : []
    );
    return parseTableRows(stringRows);
  }

  if (ext === 'csv' || ext === 'tsv') {
    const text = await file.text();
    const rows = parseDelimitedText(text);
    const fromTable = parseTableRows(rows);
    if (fromTable.length > 0) return fromTable;
    return parseTextLines(text.split(/\r?\n/));
  }

  if (ext === 'txt') {
    const text = await file.text();
    // Check if tab or comma delimited table first
    const rows = parseDelimitedText(text);
    const looksTabular = rows.length > 1 && rows.some((r) => r.length >= 2);
    if (looksTabular) {
      const fromTable = parseTableRows(rows);
      if (fromTable.length > 0) return fromTable;
    }
    return parseTextLines(text.split(/\r?\n/));
  }

  if (ext === 'docx') {
    const buffer = await file.arrayBuffer();
    return parseDocxFile(buffer);
  }

  if (ext === 'pdf') {
    const buffer = await file.arrayBuffer();
    return parsePdfFile(buffer);
  }

  throw new Error(
    `Unsupported file format ".${ext}". Please upload a CSV, Excel (.xlsx/.xls), Word (.docx), PDF (.pdf), or TXT file.`
  );
}
