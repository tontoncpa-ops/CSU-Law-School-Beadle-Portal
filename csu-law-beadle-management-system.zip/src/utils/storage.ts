import {
  BeadleStoreState,
  CourseConfig,
  MeetingRecord,
  ProfessorAttendanceStatus,
  Student,
  StudentAttendanceRecord,
  StudentAttendanceStatus,
} from '../types';

export const STORAGE_KEY = 'csu_law_beadle_system_v1';

/**
 * Returns the ISO date (YYYY-MM-DD) for the Wednesday of the current week.
 */
export function getCurrentWednesdayISO(referenceDate: Date = new Date()): string {
  const d = new Date(
    referenceDate.getFullYear(),
    referenceDate.getMonth(),
    referenceDate.getDate()
  );
  const day = d.getDay(); // 0 = Sun ... 3 = Wed ... 6 = Sat
  const diffToWednesday = 3 - day;
  d.setDate(d.getDate() + diffToWednesday);
  return formatDateToISO(d);
}

export function formatDateToISO(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function formatReadableDate(isoDate: string): string {
  if (!isoDate) return '—';
  const [y, m, d] = isoDate.split('-').map(Number);
  if (!y || !m || !d) return isoDate;
  const dateObj = new Date(y, m - 1, d);
  return dateObj.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

export function formatShortDate(isoDate: string): string {
  if (!isoDate) return '—';
  const [y, m, d] = isoDate.split('-').map(Number);
  if (!y || !m || !d) return isoDate;
  const dateObj = new Date(y, m - 1, d);
  return dateObj.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export function getMonthYearFromISO(isoDate: string): { month: number; year: number } {
  const [y, m] = isoDate.split('-').map(Number);
  return { month: m || 1, year: y || new Date().getFullYear() };
}

export interface SemesterPeriod {
  key: string;
  label: string;
  term: '1st' | '2nd' | 'Midyear';
}

/**
 * Academic semester mapping:
 * - First Semester: August (8) to December (12)
 * - Second Semester: January (1) to May (5)
 * - Midyear Term: June (6) to July (7)
 */
export function getSemesterFromMonthYear(month: number, year: number): SemesterPeriod {
  if (month >= 8 && month <= 12) {
    return {
      key: `${year}-1ST`,
      label: `1st Semester, AY ${year}–${year + 1} (Aug–Dec)`,
      term: '1st',
    };
  }
  if (month >= 1 && month <= 5) {
    return {
      key: `${year - 1}-2ND`,
      label: `2nd Semester, AY ${year - 1}–${year} (Jan–May)`,
      term: '2nd',
    };
  }
  return {
    key: `${year}-MID`,
    label: `Midyear Term ${year} (Jun–Jul)`,
    term: 'Midyear',
  };
}

export function getSemesterFromISO(isoDate: string): SemesterPeriod {
  const { month, year } = getMonthYearFromISO(isoDate);
  return getSemesterFromMonthYear(month, year);
}

export interface SemesterStudentSummary {
  unexcusedCount: number;
  excusedCount: number;
  unexcusedRecords: Array<{ date: string; remarks: string }>;
}

export function computeSemesterAbsenceMap(
  meetings: MeetingRecord[],
  students: Student[],
  semesterKey: string
): Record<string, SemesterStudentSummary> {
  const map: Record<string, SemesterStudentSummary> = {};
  for (const s of students) {
    map[s.id] = { unexcusedCount: 0, excusedCount: 0, unexcusedRecords: [] };
  }

  const semesterMeetings = meetings
    .filter((m) => getSemesterFromISO(m.date).key === semesterKey)
    .sort((a, b) => a.date.localeCompare(b.date));

  for (const mtg of semesterMeetings) {
    for (const s of students) {
      const rec = mtg.studentAttendance[s.id];
      if (!rec) continue;
      if (rec.status === 'Absent') {
        map[s.id].unexcusedCount += 1;
        map[s.id].unexcusedRecords.push({
          date: mtg.date,
          remarks: rec.remarks || '',
        });
      } else if (rec.status === 'Excused') {
        map[s.id].excusedCount += 1;
      }
    }
  }

  return map;
}

export function normalizeStudentStatus(rawStatus: string): StudentAttendanceStatus {
  if (rawStatus === 'Excused') return 'Excused';
  if (
    rawStatus === 'Absent' ||
    rawStatus === 'Absent - Sickness' ||
    rawStatus === 'Absent - Work/Travel'
  ) {
    return 'Absent';
  }
  return 'Present';
}

export function normalizeProfessorStatus(rawStatus: string): ProfessorAttendanceStatus {
  if (rawStatus === 'Late') return 'Late';
  if (rawStatus === 'Excused') return 'Excused';
  if (
    rawStatus === 'Absent' ||
    rawStatus === 'Absent - Sickness' ||
    rawStatus === 'Absent - Work/Travel'
  ) {
    return 'Absent';
  }
  return 'Present';
}

export function createBlankMeeting(
  students: Student[],
  dateOverride?: string
): MeetingRecord {
  const studentAttendance: Record<string, StudentAttendanceRecord> = {};
  for (const s of students) {
    studentAttendance[s.id] = { status: 'Present', remarks: '' };
  }
  return {
    id: `mtg-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    date: dateOverride || getCurrentWednesdayISO(),
    timeRange: '6:00 PM - 8:00 PM PHT',
    modality: 'In-Person',
    professorAttendance: { status: 'Present', remarks: '' },
    studentAttendance,
    topicsDiscussed: '',
    screenshots: [],
    updatedAt: new Date().toISOString(),
  };
}

export function loadStore(fallback: BeadleStoreState): BeadleStoreState {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw) as Partial<BeadleStoreState>;
    if (!parsed || !Array.isArray(parsed.students) || !Array.isArray(parsed.meetings)) {
      return fallback;
    }

    const mergedConfig: CourseConfig = {
      ...fallback.config,
      ...(parsed.config || {}),
    };

    if (mergedConfig.university === 'Cagayan State University') {
      mergedConfig.university = fallback.config.university;
    }
    if (mergedConfig.recipientOffice === 'Office of the Law School Dean') {
      mergedConfig.recipientOffice = fallback.config.recipientOffice;
    }
    if (!mergedConfig.units) {
      mergedConfig.units = fallback.config.units;
    }
    if (
      typeof mergedConfig.semesterMaxUnexcused !== 'number' ||
      mergedConfig.semesterMaxUnexcused < 1
    ) {
      mergedConfig.semesterMaxUnexcused = fallback.config.semesterMaxUnexcused;
    }

    const migratedMeetings: MeetingRecord[] = parsed.meetings.map((m) => {
      const nextStudentAtt: Record<string, StudentAttendanceRecord> = {};
      if (m.studentAttendance && typeof m.studentAttendance === 'object') {
        for (const [sid, rec] of Object.entries(m.studentAttendance)) {
          nextStudentAtt[sid] = {
            status: normalizeStudentStatus(rec?.status || 'Present'),
            remarks: rec?.remarks || '',
          };
        }
      }
      return {
        ...m,
        professorAttendance: {
          status: normalizeProfessorStatus(m.professorAttendance?.status || 'Present'),
          remarks: m.professorAttendance?.remarks || '',
        },
        studentAttendance: nextStudentAtt,
      };
    });

    return {
      config: mergedConfig,
      students: parsed.students,
      meetings: migratedMeetings,
    };
  } catch {
    return fallback;
  }
}

export function saveStore(state: BeadleStoreState): { ok: boolean; error?: string } {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    return { ok: true };
  } catch (err) {
    return {
      ok: false,
      error:
        err instanceof Error
          ? err.message
          : 'Storage quota exceeded. Consider removing large screenshots.',
    };
  }
}

export function fileToCompressedBase64(file: File, maxDimension = 1280): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read image file.'));
    reader.onload = () => {
      const result = reader.result;
      if (typeof result !== 'string') {
        reject(new Error('Invalid image file data.'));
        return;
      }
      const img = new Image();
      img.onerror = () => resolve(result);
      img.onload = () => {
        const scale = Math.min(1, maxDimension / Math.max(img.width, img.height));
        const targetW = Math.max(1, Math.round(img.width * scale));
        const targetH = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = targetW;
        canvas.height = targetH;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(result);
          return;
        }
        ctx.drawImage(img, 0, 0, targetW, targetH);
        const compressed = canvas.toDataURL('image/jpeg', 0.82);
        resolve(compressed);
      };
      img.src = result;
    };
    reader.readAsDataURL(file);
  });
}
