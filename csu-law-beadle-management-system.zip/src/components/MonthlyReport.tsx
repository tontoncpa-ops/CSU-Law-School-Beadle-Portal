import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  FileSpreadsheet,
  Printer,
  CalendarPlus,
} from 'lucide-react';
import { CourseConfig, MeetingRecord, Student } from '../types';
import {
  computeSemesterAbsenceMap,
  formatReadableDate,
  formatShortDate,
  getMonthYearFromISO,
  getSemesterFromMonthYear,
} from '../utils/storage';

interface MonthlyReportProps {
  config: CourseConfig;
  students: Student[];
  meetings: MeetingRecord[];
  onCreateMeetingForMonth: (year: number, month: number) => void;
}

const MONTH_NAMES = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

export const MonthlyReport: React.FC<MonthlyReportProps> = ({
  config,
  students,
  meetings,
  onCreateMeetingForMonth,
}) => {
  const defaultPeriod = useMemo(() => {
    if (meetings.length > 0) {
      const sorted = [...meetings].sort((a, b) => b.date.localeCompare(a.date));
      return getMonthYearFromISO(sorted[0].date);
    }
    const now = new Date();
    return { month: now.getMonth() + 1, year: now.getFullYear() };
  }, [meetings]);

  const [selectedMonth, setSelectedMonth] = useState<number>(defaultPeriod.month);
  const [selectedYear, setSelectedYear] = useState<number>(defaultPeriod.year);

  const availableYears = useMemo(() => {
    const years = new Set<number>([new Date().getFullYear(), selectedYear]);
    meetings.forEach((m) => {
      const { year } = getMonthYearFromISO(m.date);
      years.add(year);
    });
    return Array.from(years).sort((a, b) => b - a);
  }, [meetings, selectedYear]);

  const monthMeetings = useMemo(() => {
    return meetings
      .filter((m) => {
        const { month, year } = getMonthYearFromISO(m.date);
        return month === selectedMonth && year === selectedYear;
      })
      .sort((a, b) => a.date.localeCompare(b.date));
  }, [meetings, selectedMonth, selectedYear]);

  const semesterInfo = useMemo(
    () => getSemesterFromMonthYear(selectedMonth, selectedYear),
    [selectedMonth, selectedYear]
  );

  const semesterAbsenceMap = useMemo(
    () => computeSemesterAbsenceMap(meetings, students, semesterInfo.key),
    [meetings, students, semesterInfo.key]
  );

  const maxUnexcused = config.semesterMaxUnexcused || 3;

  // Consolidated student statistics (month + semester cumulative unexcused)
  const studentStats = useMemo(() => {
    return students.map((student) => {
      let present = 0;
      let absent = 0;
      let excused = 0;

      for (const mtg of monthMeetings) {
        const rec = mtg.studentAttendance[student.id];
        const status = rec?.status || 'Present';
        if (status === 'Present') {
          present += 1;
        } else if (status === 'Excused') {
          excused += 1;
        } else {
          absent += 1;
        }
      }

      const totalSessions = monthMeetings.length;
      const attendedEquivalent = present + excused;
      const attendanceRate =
        totalSessions > 0
          ? Math.round((attendedEquivalent / totalSessions) * 100)
          : 100;

      const semData = semesterAbsenceMap[student.id] || {
        unexcusedCount: 0,
        excusedCount: 0,
        unexcusedRecords: [],
      };
      const semUnexcused = semData.unexcusedCount;
      const isExceeded = semUnexcused > maxUnexcused;
      const isAtLimit = semUnexcused === maxUnexcused;
      const isApproaching = maxUnexcused > 1 && semUnexcused === maxUnexcused - 1;

      return {
        student,
        present,
        absent,
        excused,
        attendanceRate,
        semUnexcused,
        semExcused: semData.excusedCount,
        semUnexcusedRecords: semData.unexcusedRecords,
        isExceeded,
        isAtLimit,
        isApproaching,
      };
    });
  }, [students, monthMeetings, semesterAbsenceMap, maxUnexcused]);

  const professorStats = useMemo(() => {
    let present = 0;
    let late = 0;
    let absent = 0;
    let excused = 0;
    for (const mtg of monthMeetings) {
      const st = mtg.professorAttendance.status;
      if (st === 'Present') present += 1;
      else if (st === 'Late') late += 1;
      else if (st === 'Excused') excused += 1;
      else absent += 1;
    }
    return { present, late, absent, excused };
  }, [monthMeetings]);

  const flaggedStudents = studentStats.filter(
    (s) => s.isExceeded || s.isAtLimit || s.isApproaching
  );
  const periodLabel = `${MONTH_NAMES[selectedMonth - 1]} ${selectedYear}`;
  const todayFormatted = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div className="space-y-6">
      {/* Control Toolbar (hidden when printing) */}
      <div className="no-print bg-white border border-slate-200 rounded-lg p-4 sm:px-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <div>
            <label
              htmlFor="report-month-select"
              className="block text-xs font-medium text-slate-500 mb-1"
            >
              Reporting Month
            </label>
            <select
              id="report-month-select"
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(Number(e.target.value))}
              className="px-3 py-2 text-sm font-medium text-slate-900 bg-slate-50 border border-slate-200 rounded-md focus:bg-white focus:outline-none focus:border-navy-700"
            >
              {MONTH_NAMES.map((name, idx) => (
                <option key={name} value={idx + 1}>
                  {name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label
              htmlFor="report-year-select"
              className="block text-xs font-medium text-slate-500 mb-1"
            >
              Year
            </label>
            <select
              id="report-year-select"
              value={selectedYear}
              onChange={(e) => setSelectedYear(Number(e.target.value))}
              className="px-3 py-2 text-sm font-medium font-mono tabular-nums text-slate-900 bg-slate-50 border border-slate-200 rounded-md focus:bg-white focus:outline-none focus:border-navy-700"
            >
              {availableYears.map((yr) => (
                <option key={yr} value={yr}>
                  {yr}
                </option>
              ))}
            </select>
          </div>

          <div className="sm:pl-3 sm:border-l sm:border-slate-200 pt-1 sm:pt-4">
            <div className="text-xs text-slate-600 tabular-nums">
              {monthMeetings.length}{' '}
              {monthMeetings.length === 1 ? 'session' : 'sessions'} recorded for{' '}
              <span className="font-semibold text-slate-900">{periodLabel}</span>
            </div>
            <div className="text-[11px] text-slate-500">
              {semesterInfo.label}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => window.print()}
            disabled={monthMeetings.length === 0}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-navy-900 rounded-md hover:bg-navy-800 disabled:opacity-40 disabled:cursor-not-allowed transition-colors whitespace-nowrap shrink-0"
          >
            <Printer className="w-4 h-4" aria-hidden="true" />
            <span>Print / Save as PDF</span>
          </button>
        </div>
      </div>

      {/* Empty state if no sessions in selected month */}
      {monthMeetings.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-lg px-6 py-16 text-center">
          <FileSpreadsheet
            className="w-10 h-10 text-slate-400 mx-auto mb-3"
            aria-hidden="true"
          />
          <h2 className="text-base font-semibold text-slate-900">
            No class sessions logged for {periodLabel}
          </h2>
          <p className="text-sm text-slate-500 mt-1 max-w-md mx-auto">
            Record at least one session in {periodLabel} to generate the formal Monthly Beadle Report for the {config.recipientOffice}.
          </p>
          <button
            type="button"
            onClick={() => onCreateMeetingForMonth(selectedYear, selectedMonth)}
            className="mt-5 inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-navy-900 rounded-md hover:bg-navy-800 transition-colors"
          >
            <CalendarPlus className="w-4 h-4" aria-hidden="true" />
            <span>Log a Session for {periodLabel}</span>
          </button>
        </div>
      ) : (
        /* Printable Formal Document */
        <article className="print-container bg-white border border-slate-200 rounded-lg p-6 sm:p-10 max-w-4xl mx-auto text-slate-900">
          {/* Formal Institutional Header */}
          <header className="border-b-2 border-navy-900 pb-6 mb-6">
            <div className="text-center space-y-1">
              <div className="text-lg sm:text-xl font-bold tracking-tight text-navy-900">
                {config.university}
              </div>
              <div className="text-sm font-semibold text-slate-700">
                {config.college}
              </div>
              <div className="text-xs font-medium text-slate-600">
                {config.recipientOffice}
              </div>
            </div>

            <div className="mt-6 pt-5 border-t border-slate-200">
              <h1 className="text-base sm:text-lg font-bold text-navy-900 text-center mb-4">
                Monthly Class Beadle Attendance &amp; Progress Report
              </h1>

              <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-2 text-xs">
                <div className="flex justify-between sm:justify-start gap-2 border-b border-slate-100 pb-1.5">
                  <dt className="font-semibold text-slate-600 w-32 shrink-0">
                    Subject / Course:
                  </dt>
                  <dd className="text-slate-900 font-medium">
                    {config.courseTitle}
                    {config.units ? ` (${config.units})` : ''}
                  </dd>
                </div>
                <div className="flex justify-between sm:justify-start gap-2 border-b border-slate-100 pb-1.5">
                  <dt className="font-semibold text-slate-600 w-32 shrink-0">
                    Reporting Period:
                  </dt>
                  <dd className="text-slate-900 font-medium tabular-nums">
                    {periodLabel}
                  </dd>
                </div>
                <div className="flex justify-between sm:justify-start gap-2 border-b border-slate-100 pb-1.5">
                  <dt className="font-semibold text-slate-600 w-32 shrink-0">
                    Academic Term:
                  </dt>
                  <dd className="text-slate-900">{semesterInfo.label}</dd>
                </div>
                <div className="flex justify-between sm:justify-start gap-2 border-b border-slate-100 pb-1.5">
                  <dt className="font-semibold text-slate-600 w-32 shrink-0">
                    Class Schedule:
                  </dt>
                  <dd className="text-slate-900">{config.scheduleLabel}</dd>
                </div>
                <div className="flex justify-between sm:justify-start gap-2 border-b border-slate-100 pb-1.5">
                  <dt className="font-semibold text-slate-600 w-32 shrink-0">
                    Course Professor:
                  </dt>
                  <dd className="text-slate-900">{config.professorName}</dd>
                </div>
                <div className="flex justify-between sm:justify-start gap-2 border-b border-slate-100 pb-1.5">
                  <dt className="font-semibold text-slate-600 w-32 shrink-0">
                    Class Beadle:
                  </dt>
                  <dd className="text-slate-900">{config.beadleName}</dd>
                </div>
                <div className="flex justify-between sm:justify-start gap-2 border-b border-slate-100 pb-1.5 sm:col-span-2">
                  <dt className="font-semibold text-slate-600 w-32 shrink-0">
                    Date Prepared:
                  </dt>
                  <dd className="text-slate-900 tabular-nums">{todayFormatted}</dd>
                </div>
              </dl>
            </div>
          </header>

          {/* Section I: Summary of Dates Met */}
          <section className="mb-8 print-break-inside-avoid">
            <h2 className="text-sm font-bold text-navy-900 mb-2">
              I. Summary of Class Dates Met
            </h2>
            <p className="text-xs text-slate-600 mb-3 tabular-nums">
              Sessions Conducted: {monthMeetings.length} · Professor Present:{' '}
              {professorStats.present} · Professor Late: {professorStats.late} ·
              Professor Absent/Excused: {professorStats.absent + professorStats.excused}
            </p>

            <div className="overflow-x-auto border border-slate-200 rounded-md">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-700 font-semibold">
                    <th className="py-2.5 px-3 w-12">No.</th>
                    <th className="py-2.5 px-3">Date Met</th>
                    <th className="py-2.5 px-3">Time</th>
                    <th className="py-2.5 px-3">Format</th>
                    <th className="py-2.5 px-3">Professor Status</th>
                    <th className="py-2.5 px-3">Professor / Session Remarks</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {monthMeetings.map((mtg, idx) => (
                    <tr key={mtg.id}>
                      <td className="py-2.5 px-3 font-mono tabular-nums text-slate-500">
                        {String(idx + 1).padStart(2, '0')}
                      </td>
                      <td className="py-2.5 px-3 font-medium text-slate-900 whitespace-nowrap">
                        {formatReadableDate(mtg.date)}
                      </td>
                      <td className="py-2.5 px-3 font-mono tabular-nums text-slate-700 whitespace-nowrap">
                        {mtg.timeRange}
                      </td>
                      <td className="py-2.5 px-3 text-slate-700 whitespace-nowrap">
                        {mtg.modality}
                      </td>
                      <td className="py-2.5 px-3 font-medium text-slate-900 whitespace-nowrap">
                        {mtg.professorAttendance.status}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600">
                        {mtg.professorAttendance.remarks || '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          {/* Section II: Consolidated Attendance Statistics */}
          <section className="mb-8 print-break-inside-avoid">
            <h2 className="text-sm font-bold text-navy-900 mb-2">
              II. Consolidated Student Attendance Statistics
            </h2>
            <p className="text-xs text-slate-600 mb-3 tabular-nums">
              Semester Policy: Maximum of {maxUnexcused} unexcused absences allowed per semester ({semesterInfo.label}). Excused absences do not count toward this limit.
            </p>

            <div className="overflow-x-auto border border-slate-200 rounded-md">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-700 font-semibold">
                    <th className="py-2.5 px-3">Student Name</th>
                    <th className="py-2.5 px-2.5 text-right">Present</th>
                    <th className="py-2.5 px-2.5 text-right">Absent</th>
                    <th className="py-2.5 px-2.5 text-right">Excused</th>
                    <th className="py-2.5 px-2.5 text-right">Rate</th>
                    <th className="py-2.5 px-3 text-right">Sem. Unexcused</th>
                    <th className="py-2.5 px-3">Semester Standing</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {studentStats.map((row) => (
                    <tr
                      key={row.student.id}
                      className={
                        row.isExceeded
                          ? 'bg-red-50/40'
                          : row.isAtLimit
                          ? 'bg-amber-50/40'
                          : ''
                      }
                    >
                      <td className="py-2.5 px-3">
                        <div className="font-medium text-slate-900">
                          {row.student.fullName}
                        </div>
                        <div className="text-[11px] font-mono tabular-nums text-slate-500">
                          {row.student.studentNo}
                        </div>
                      </td>
                      <td className="py-2.5 px-2.5 text-right font-mono tabular-nums text-slate-800">
                        {row.present}
                      </td>
                      <td className="py-2.5 px-2.5 text-right font-mono tabular-nums text-slate-800">
                        {row.absent}
                      </td>
                      <td className="py-2.5 px-2.5 text-right font-mono tabular-nums text-slate-800">
                        {row.excused}
                      </td>
                      <td className="py-2.5 px-2.5 text-right font-mono tabular-nums text-slate-800">
                        {row.attendanceRate}%
                      </td>
                      <td
                        className={`py-2.5 px-3 text-right font-mono tabular-nums font-semibold ${
                          row.isExceeded
                            ? 'text-red-700'
                            : row.isAtLimit
                            ? 'text-amber-800'
                            : row.isApproaching
                            ? 'text-amber-700'
                            : 'text-slate-900'
                        }`}
                      >
                        {row.semUnexcused} / {maxUnexcused}
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        {row.isExceeded ? (
                          <span className="inline-flex items-center gap-1 font-semibold text-red-700">
                            <AlertTriangle
                              className="w-3.5 h-3.5 shrink-0"
                              aria-hidden="true"
                            />
                            <span>Exceeded Limit (&gt;{maxUnexcused})</span>
                          </span>
                        ) : row.isAtLimit ? (
                          <span className="inline-flex items-center gap-1 font-semibold text-amber-800">
                            <AlertTriangle
                              className="w-3.5 h-3.5 shrink-0"
                              aria-hidden="true"
                            />
                            <span>At Limit ({row.semUnexcused}/{maxUnexcused})</span>
                          </span>
                        ) : row.isApproaching ? (
                          <span className="inline-flex items-center gap-1 font-medium text-amber-700">
                            <AlertTriangle
                              className="w-3.5 h-3.5 shrink-0"
                              aria-hidden="true"
                            />
                            <span>Warning ({row.semUnexcused}/{maxUnexcused})</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-emerald-700 font-medium">
                            <CheckCircle2
                              className="w-3.5 h-3.5 shrink-0"
                              aria-hidden="true"
                            />
                            <span>Good Standing</span>
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {flaggedStudents.length > 0 && (
              <div className="mt-4 p-4 bg-amber-50/60 border border-amber-200 rounded-md">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-900 mb-2">
                  <AlertTriangle
                    className="w-4 h-4 text-red-700 shrink-0"
                    aria-hidden="true"
                  />
                  <span>
                    Semester Absence Policy Notice ({semesterInfo.label} · Limit: {maxUnexcused} Unexcused)
                  </span>
                </div>
                <ul className="space-y-1.5 text-xs text-slate-800">
                  {flaggedStudents.map((item) => (
                    <li key={item.student.id}>
                      <span className="font-semibold">
                        {item.student.fullName} ({item.student.studentNo})
                      </span>
                      {' — '}
                      <span
                        className={
                          item.isExceeded
                            ? 'font-semibold text-red-700'
                            : 'font-semibold text-amber-800'
                        }
                      >
                        {item.isExceeded
                          ? `Exceeded limit (${item.semUnexcused}/${maxUnexcused} unexcused)`
                          : item.isAtLimit
                          ? `At final limit (${item.semUnexcused}/${maxUnexcused} unexcused)`
                          : `Approaching limit (${item.semUnexcused}/${maxUnexcused} unexcused)`}
                      </span>
                      {item.semUnexcusedRecords.length > 0 && (
                        <span>
                          :{' '}
                          {item.semUnexcusedRecords
                            .map(
                              (n) =>
                                `${formatShortDate(n.date)}${
                                  n.remarks ? ` ("${n.remarks}")` : ''
                                }`
                            )
                            .join('; ')}
                        </span>
                      )}
                      {item.semExcused > 0 && (
                        <span className="text-slate-600">
                          {' '}
                          · {item.semExcused} excused (excluded from limit)
                        </span>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </section>

          {/* Section III: Chronological Digest of Topics Discussed & Documentation */}
          <section className="mb-10">
            <h2 className="text-sm font-bold text-navy-900 mb-3">
              III. Chronological Digest of Topics Discussed &amp; Class Documentation
            </h2>

            <div className="space-y-6">
              {monthMeetings.map((mtg, idx) => {
                const notableStudentRemarks = students
                  .map((s) => ({
                    student: s,
                    record: mtg.studentAttendance[s.id],
                  }))
                  .filter(
                    (entry) =>
                      entry.record &&
                      (entry.record.status !== 'Present' ||
                        entry.record.remarks.trim().length > 0)
                  );

                return (
                  <div
                    key={mtg.id}
                    className="border border-slate-200 rounded-md p-5 print-break-inside-avoid"
                  >
                    <div className="flex flex-wrap items-baseline justify-between gap-2 pb-3 mb-3 border-b border-slate-200">
                      <h3 className="text-sm font-bold text-navy-900">
                        Session {idx + 1}: {formatReadableDate(mtg.date)}
                      </h3>
                      <div className="text-xs font-mono tabular-nums text-slate-600">
                        {mtg.timeRange} · {mtg.modality}
                      </div>
                    </div>

                    <div className="space-y-4 text-xs">
                      <div>
                        <div className="font-semibold text-slate-700 mb-1">
                          Professor Attendance
                        </div>
                        <div className="text-slate-900">
                          {config.professorName} —{' '}
                          <span className="font-semibold">
                            {mtg.professorAttendance.status}
                          </span>
                          {mtg.professorAttendance.remarks
                            ? ` (${mtg.professorAttendance.remarks})`
                            : ''}
                        </div>
                      </div>

                      <div>
                        <div className="font-semibold text-slate-700 mb-1">
                          Class Accomplishments &amp; Topics Discussed
                        </div>
                        {mtg.topicsDiscussed.trim() ? (
                          <div className="text-slate-800 whitespace-pre-line leading-relaxed bg-slate-50 border border-slate-200 rounded p-3">
                            {mtg.topicsDiscussed}
                          </div>
                        ) : (
                          <div className="text-slate-400 italic">
                            No narrative documentation entered for this session.
                          </div>
                        )}
                      </div>

                      {notableStudentRemarks.length > 0 && (
                        <div>
                          <div className="font-semibold text-slate-700 mb-1">
                            Attendance Exceptions &amp; Remarks
                          </div>
                          <ul className="space-y-1 text-slate-700">
                            {notableStudentRemarks.map(({ student, record }) => (
                              <li key={student.id}>
                                <span className="font-medium text-slate-900">
                                  {student.fullName}
                                </span>{' '}
                                <span
                                  className={
                                    record.status === 'Absent'
                                      ? 'font-semibold text-red-700'
                                      : 'font-medium text-slate-700'
                                  }
                                >
                                  [{record.status}]
                                </span>
                                {record.remarks ? ` — ${record.remarks}` : ''}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {mtg.screenshots.length > 0 && (
                        <div>
                          <div className="font-semibold text-slate-700 mb-2">
                            Photographic / Screenshot Documentation
                          </div>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            {mtg.screenshots.map((shot) => (
                              <figure
                                key={shot.id}
                                className="border border-slate-200 rounded overflow-hidden bg-slate-50"
                              >
                                <img
                                  src={shot.dataUrl}
                                  alt={shot.caption || shot.name}
                                  referrerPolicy="no-referrer"
                                  className="w-full h-44 object-cover"
                                />
                                <figcaption className="px-2.5 py-1.5 text-[11px] text-slate-600 border-t border-slate-200 bg-white">
                                  {shot.caption || shot.name}
                                </figcaption>
                              </figure>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          {/* Formal Sign-Off Block */}
          <footer className="pt-8 border-t border-slate-300 print-break-inside-avoid">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 text-xs">
              <div>
                <div className="text-slate-500 mb-8">
                  Certified True and Correct:
                </div>
                <div className="border-t border-slate-800 pt-1.5 font-semibold text-slate-900">
                  {config.beadleName}
                </div>
                <div className="text-slate-600">
                  Class Beadle, {config.courseTitle}
                </div>
              </div>

              <div>
                <div className="text-slate-500 mb-8">Noted by:</div>
                <div className="border-t border-slate-800 pt-1.5 font-semibold text-slate-900">
                  {config.professorName}
                </div>
                <div className="text-slate-600">Course Professor</div>
              </div>

              <div>
                <div className="text-slate-500 mb-8">Submitted to:</div>
                <div className="border-t border-slate-800 pt-1.5 font-semibold text-slate-900">
                  {config.recipientOffice}
                </div>
                <div className="text-slate-600">{config.university}</div>
              </div>
            </div>
          </footer>
        </article>
      )}
    </div>
  );
};
