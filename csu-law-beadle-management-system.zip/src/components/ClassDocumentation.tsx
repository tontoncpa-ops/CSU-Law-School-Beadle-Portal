import React, { useRef, useState } from 'react';
import {
  ImagePlus,
  Trash2,
  Maximize2,
  X,
  FileText,
  Upload,
} from 'lucide-react';
import { ClassScreenshot } from '../types';
import { fileToCompressedBase64 } from '../utils/storage';

interface ClassDocumentationProps {
  topicsDiscussed: string;
  onTopicsChange: (value: string) => void;
  screenshots: ClassScreenshot[];
  onScreenshotsChange: (next: ClassScreenshot[]) => void;
}

export const ClassDocumentation: React.FC<ClassDocumentationProps> = ({
  topicsDiscussed,
  onTopicsChange,
  screenshots,
  onScreenshotsChange,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [previewImage, setPreviewImage] = useState<ClassScreenshot | null>(null);

  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setUploadError(null);
    setIsUploading(true);

    try {
      const added: ClassScreenshot[] = [];
      for (const file of Array.from(files)) {
        if (!file.type.startsWith('image/')) {
          setUploadError(`Skipped "${file.name}": only image files are supported.`);
          continue;
        }
        const dataUrl = await fileToCompressedBase64(file);
        added.push({
          id: `img-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          name: file.name,
          dataUrl,
          caption: file.name.replace(/\.[^/.]+$/, '').replace(/[_-]+/g, ' '),
          uploadedAt: new Date().toISOString(),
        });
      }
      if (added.length > 0) {
        onScreenshotsChange([...screenshots, ...added]);
      }
    } catch (err) {
      setUploadError(
        err instanceof Error ? err.message : 'Unable to process image upload.'
      );
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    void handleFiles(e.dataTransfer.files);
  };

  const insertPromptSection = (snippet: string) => {
    const prefix = topicsDiscussed.trim().length > 0 ? '\n' : '';
    onTopicsChange(`${topicsDiscussed}${prefix}${snippet}`);
  };

  const updateCaption = (id: string, caption: string) => {
    onScreenshotsChange(
      screenshots.map((img) => (img.id === id ? { ...img, caption } : img))
    );
  };

  const removeScreenshot = (id: string) => {
    onScreenshotsChange(screenshots.filter((img) => img.id !== id));
  };

  const wordCount = topicsDiscussed.trim()
    ? topicsDiscussed.trim().split(/\s+/).length
    : 0;

  return (
    <div className="space-y-6">
      {/* Narrative / Topics Discussed */}
      <section
        aria-labelledby="topics-discussed-heading"
        className="bg-white border border-slate-200 rounded-lg"
      >
        <div className="px-5 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2
              id="topics-discussed-heading"
              className="text-base font-semibold text-navy-900"
            >
              Class Accomplishments &amp; Topics Discussed
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Formal narrative included in the monthly submission to the Office of the Dean
            </p>
          </div>
          <span className="text-xs font-mono tabular-nums text-slate-500">
            {wordCount} {wordCount === 1 ? 'word' : 'words'}
          </span>
        </div>

        <div className="p-5 space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-medium text-slate-500">
              Quick Insert:
            </span>
            <button
              type="button"
              onClick={() => insertPromptSection('Topics Covered: ')}
              className="px-2.5 py-1 text-xs font-medium text-navy-900 bg-slate-100 hover:bg-slate-200 rounded transition-colors whitespace-nowrap"
            >
              + Topics Covered
            </button>
            <button
              type="button"
              onClick={() => insertPromptSection('Cases Discussed: ')}
              className="px-2.5 py-1 text-xs font-medium text-navy-900 bg-slate-100 hover:bg-slate-200 rounded transition-colors whitespace-nowrap"
            >
              + Cases Discussed
            </button>
            <button
              type="button"
              onClick={() => insertPromptSection('Statutory Provisions (R.A. 7160): ')}
              className="px-2.5 py-1 text-xs font-medium text-navy-900 bg-slate-100 hover:bg-slate-200 rounded transition-colors whitespace-nowrap"
            >
              + R.A. 7160 Provisions
            </button>
            <button
              type="button"
              onClick={() => insertPromptSection('Next Meeting Assignment: ')}
              className="px-2.5 py-1 text-xs font-medium text-navy-900 bg-slate-100 hover:bg-slate-200 rounded transition-colors whitespace-nowrap"
            >
              + Assignment
            </button>
          </div>

          <textarea
            id="topics-discussed-textarea"
            rows={8}
            value={topicsDiscussed}
            onChange={(e) => onTopicsChange(e.target.value)}
            placeholder={
              'Document the lecture coverage, statutory provisions (e.g., R.A. 7160 Secs. 1–24), Supreme Court jurisprudence recited, and upcoming assignments...'
            }
            className="w-full px-3.5 py-3 text-sm leading-relaxed text-slate-900 bg-slate-50 border border-slate-200 rounded-md placeholder:text-slate-400 focus:bg-white focus:outline-none focus:border-navy-700 focus:ring-1 focus:ring-navy-700 transition-colors resize-y"
          />
        </div>
      </section>

      {/* Class Screenshots / Photo Evidence */}
      <section
        aria-labelledby="class-screenshots-heading"
        className="bg-white border border-slate-200 rounded-lg"
      >
        <div className="px-5 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2
              id="class-screenshots-heading"
              className="text-base font-semibold text-navy-900"
            >
              Class Screenshots &amp; Documentation Photos
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Attach lecture photos, whiteboard diagrams, or online session captures (stored locally as Base64)
            </p>
          </div>
          <span className="text-xs font-mono tabular-nums text-slate-500">
            {screenshots.length} {screenshots.length === 1 ? 'Attachment' : 'Attachments'}
          </span>
        </div>

        <div className="p-5 space-y-5">
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
            className={`border border-dashed rounded-lg p-6 text-center transition-colors ${
              isDragging
                ? 'border-navy-700 bg-navy-50'
                : 'border-slate-300 bg-slate-50 hover:border-slate-400'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={(e) => void handleFiles(e.target.files)}
              className="sr-only"
              id="class-photo-upload"
            />
            <Upload
              className="w-6 h-6 text-slate-400 mx-auto mb-2"
              aria-hidden="true"
            />
            <p className="text-sm font-medium text-slate-800">
              {isUploading
                ? 'Processing image...'
                : 'Drag and drop class photos or screenshots here'}
            </p>
            <p className="text-xs text-slate-500 mt-1 mb-3">
              PNG, JPG, or WebP · Automatically optimized for browser storage
            </p>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-navy-900 rounded-md hover:bg-navy-800 disabled:opacity-50 transition-colors"
            >
              <ImagePlus className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Select Image Files</span>
            </button>
          </div>

          {uploadError && (
            <div
              role="alert"
              className="px-3.5 py-2.5 text-xs text-red-800 bg-red-50 border border-red-200 rounded-md"
            >
              {uploadError}
            </div>
          )}

          {screenshots.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {screenshots.map((shot) => (
                <div
                  key={shot.id}
                  className="border border-slate-200 rounded-lg overflow-hidden bg-white flex flex-col"
                >
                  <div className="relative aspect-[4/3] bg-slate-100 overflow-hidden group">
                    {shot.dataUrl ? (
                      <img
                        src={shot.dataUrl}
                        alt={shot.caption || shot.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center text-slate-400">
                        <FileText className="w-8 h-8 mb-1" />
                        <span className="text-xs">Image unavailable</span>
                      </div>
                    )}
                    <div className="absolute top-2 right-2 flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setPreviewImage(shot)}
                        aria-label={`Preview ${shot.caption || shot.name}`}
                        className="p-2 bg-white/95 text-slate-800 border border-slate-200 rounded-md hover:bg-white shadow-sm transition-colors"
                      >
                        <Maximize2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => removeScreenshot(shot.id)}
                        aria-label={`Remove ${shot.caption || shot.name}`}
                        className="p-2 bg-white/95 text-red-700 border border-slate-200 rounded-md hover:bg-red-50 shadow-sm transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="p-3 border-t border-slate-200 space-y-1.5">
                    <label
                      htmlFor={`caption-${shot.id}`}
                      className="block text-xs font-medium text-slate-500"
                    >
                      Photo Caption
                    </label>
                    <input
                      id={`caption-${shot.id}`}
                      type="text"
                      value={shot.caption}
                      onChange={(e) => updateCaption(shot.id, e.target.value)}
                      placeholder="Describe screenshot or whiteboard note"
                      className="w-full px-2.5 py-1.5 text-xs text-slate-900 bg-slate-50 border border-slate-200 rounded focus:bg-white focus:outline-none focus:border-navy-700"
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Lightbox Modal */}
      {previewImage && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Screenshot preview"
          className="fixed inset-0 z-50 bg-slate-950/80 flex items-center justify-center p-4"
          onClick={() => setPreviewImage(null)}
        >
          <div
            className="bg-white rounded-lg max-w-4xl w-full overflow-hidden border border-slate-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between gap-4">
              <div className="text-sm font-medium text-slate-900 truncate">
                {previewImage.caption || previewImage.name}
              </div>
              <button
                type="button"
                onClick={() => setPreviewImage(null)}
                aria-label="Close preview"
                className="p-1.5 text-slate-500 hover:text-slate-900 rounded-md hover:bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="bg-slate-900 flex items-center justify-center max-h-[75vh]">
              <img
                src={previewImage.dataUrl}
                alt={previewImage.caption || previewImage.name}
                referrerPolicy="no-referrer"
                className="max-h-[75vh] w-auto object-contain"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
