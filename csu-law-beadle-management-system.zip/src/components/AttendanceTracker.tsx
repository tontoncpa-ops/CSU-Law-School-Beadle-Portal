import React, { useState } from 'react';
import {
  AlertTriangle,
  Check,
  Clock,
  FileCheck2,
  XCircle,
  Search,
  UserCheck,
  Users,
} from 'lucide-react';
import {
  PROFESSOR_ATTENDANCE_STATUSES,
  ProfessorAttendanceRecord,
  ProfessorAttendanceStatus,
  STUDENT_ATTENDANCE_STATUSES,
  Student,
  StudentAttendanceRecord,
  StudentAttendanceStatus,
} from '../types';
import { SemesterStudentSummary } from '../utils/storage';

interface AttendanceTrackerProps {
  courseTitle: string;
  units: string;
  professorName: string;
  professorAttendance: ProfessorAttendanceRecord;
  onProfessorChange: (next: ProfessorAttendanceRecord) => void;
  students: Student[];
  studentAttendance: Record<string, StudentAttendanceRecord>;
  onStudentChange: (studentId: string, next: StudentAttendanceRecord) => void;
  onMarkAllPresent: () => void;
  onOpenRoster: () => void;
  semesterLabel: string;
  semesterMaxUnexcused: number;
  semesterAbsenceMap: Record<string, SemesterStudentSummary>;
}

function getStatusVisuals(status: ProfessorAttendanceStatus | StudentAttendanceStatus) {
  switch (status) {
    case 'Present':
      return {
        icon: Check,
        activeClass: 'bg-emerald-700 text-white border-emerald-700',
        idleHover: 'hover:border-emerald-300 hover:text-emerald-800',
      };
    case 'Late':
      return {
        icon: Clock,
        activeClass: 'bg-amber-600 text-white border-amber-600',
        idleHover: 'hover:border-amber-300 hover:text-amber-800',
      };
    case 'Absent':
      return {
        icon: XCircle,
        activeClass: 'bg-red-700 text-white border-red-700',
        idleHover: 'hover:border-red-300 hover:text-red-800',
      };
    case 'Excused':
      return {
        icon: FileCheck2,
        activeClass: 'bg-navy-800 text-white border-navy-800',
        idleHover: 'hover:border-navy-300 hover:text-navy-800',
      };
  }
}

export const AttendanceTracker: React.FC<AttendanceTrackerProps> = ({
  courseTitle,
  units,
  professorName,
  professorAttendance,
  onProfessorChange,
  students,
  studentAttendance,
  onStudentChange,
  onMarkAllPresent,
  onOpenRoster,
  semesterLabel,
  semesterMaxUnexcused,
  semesterAbsenceMap,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredStudents = students.filter((s) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      s.fullName.toLowerCase().includes(q) ||
      s.studentNo.toLowerCase().includes(q)
    );
  });

  const counts = students.reduce(
    (acc, s) => {
      const st = studentAttendance[s.id]?.status || 'Present';
      if (st === 'Present') acc.present += 1;
      else if (st === 'Excused') acc.excused += 1;
      else acc.absent += 1;
      return acc;
    },
    { present: 0, absent: 0, excused: 0 }
  );

  return (
    <div className="space-y-6">
      {/* Section 1: Professor Attendance */}
      <section
        aria-labelledby="professor-attendance-heading"
        className="bg-white border border-slate-200 rounded-lg"
      >
        <div className="px-5 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2
              id="professor-attendance-heading"
              className="text-base font-semibold text-navy-900"
            >
              Professor Attendance
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Faculty Presence &amp; Session Delivery Record
            </p>
          </div>
          <span className="text-xs font-medium text-slate-600">
            Course Instructor
          </span>
        </div>

        <div className="p-5 space-y-4">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
            <div className="min-w-0">
              <div className="text-sm font-semibold text-slate-900">
                {professorName || 'Course Professor'}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">
                {courseTitle}
                {units ? ` · ${units}` : ''}
              </div>
            </div>

            <div
              role="radiogroup"
              aria-label={`Attendance status for ${professorName || 'Professor'}`}
              className="flex flex-wrap gap-1.5"
            >
              {PROFESSOR_ATTENDANCE_STATUSES.map((status) => {
                const isActive = professorAttendance.status === status;
                const { icon: Icon, activeClass, idleHover } =
                  getStatusVisuals(status);
                return (
                  <button
                    key={status}
                    type="button"
                    role="radio"
                    aria-checked={isActive}
                    onClick={() =>
                      onProfessorChange({ ...professorAttendance, status })
                    }
                    className={`inline-flex items-center gap-1.5 px-3 py-2 min-h-[40px] sm:min-h-[36px] text-xs font-medium rounded-md border transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-navy-800 ${
                      isActive
                        ? activeClass
                        : `bg-white text-slate-700 border-slate-200 ${idleHover}`
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                    <span>{status}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <label
              htmlFor="professor-remarks"
              className="block text-xs font-medium text-slate-600 mb-1.5"
            >
              Professor Remarks
            </label>
            <input
              id="professor-remarks"
              type="text"
              value={professorAttendance.remarks}
              onChange={(e) =>
                onProfessorChange({
                  ...professorAttendance,
                  remarks: e.target.value,
                })
              }
              placeholder="e.g., Arrived on time; conducted Socratic recitation; assigned next week's cases"
              className="w-full px-3 py-2 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-md placeholder:text-slate-400 focus:bg-white focus:outline-none focus:border-navy-700 focus:ring-1 focus:ring-navy-700 transition-colors"
            />
          </div>
        </div>
      </section>

      {/* Section 2: Student Attendance */}
      <section
        aria-labelledby="student-attendance-heading"
        className="bg-white border border-slate-200 rounded-lg"
      >
        <div className="px-5 py-4 border-b border-slate-200 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h2
              id="student-attendance-heading"
              className="text-base font-semibold text-navy-900"
            >
              Student Attendance
            </h2>
            <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-600 mt-1 tabular-nums">
              <span>{students.length} Enrolled</span>
              <span aria-hidden="true">·</span>
              <span className="text-emerald-700 font-medium">
                {counts.present} Present
              </span>
              <span aria-hidden="true">·</span>
              <span className="text-red-700 font-medium">
                {counts.absent} Absent
              </span>
              <span aria-hidden="true">·</span>
              <span className="text-navy-800 font-medium">
                {counts.excused} Excused
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mt-1 tabular-nums">
              {semesterLabel} · Max {semesterMaxUnexcused} unexcused absences per semester (Excused excluded)
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="relative flex-1 sm:flex-initial sm:w-56">
              <Search
                className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Filter student..."
                aria-label="Filter student roster"
                className="w-full pl-9 pr-3 py-2 text-xs text-slate-900 bg-slate-50 border border-slate-200 rounded-md placeholder:text-slate-400 focus:bg-white focus:outline-none focus:border-navy-700"
              />
            </div>

            <button
              type="button"
              onClick={onMarkAllPresent}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-navy-900 bg-navy-50 border border-navy-200 rounded-md hover:bg-navy-100 transition-colors whitespace-nowrap shrink-0"
            >
              <UserCheck className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Mark All Present</span>
            </button>
          </div>
        </div>

        {students.length === 0 ? (
          <div className="px-6 py-12 text-center">
            <Users className="w-8 h-8 text-slate-400 mx-auto mb-3" aria-hidden="true" />
            <p className="text-sm font-medium text-slate-900">
              No students in the class roster
            </p>
            <p className="text-xs text-slate-500 mt-1 mb-4">
              Add students to your {courseTitle} roster to begin logging attendance.
            </p>
            <button
              type="button"
              onClick={onOpenRoster}
              className="px-4 py-2 text-xs font-medium text-white bg-navy-900 rounded-md hover:bg-navy-800 transition-colors"
            >
              Manage Class Roster
            </button>
          </div>
        ) : filteredStudents.length === 0 ? (
          <div className="px-6 py-8 text-center text-sm text-slate-500">
            No students match &ldquo;{searchQuery}&rdquo;.
          </div>
        ) : (
          <div className="divide-y divide-slate-200">
            {filteredStudents.map((student, index) => {
              const record = studentAttendance[student.id] || {
                status: 'Present' as StudentAttendanceStatus,
                remarks: '',
              };
              const semStats = semesterAbsenceMap[student.id] || {
                unexcusedCount: 0,
                excusedCount: 0,
                unexcusedRecords: [],
              };
              const unexcused = semStats.unexcusedCount;
              const isExceeded = unexcused > semesterMaxUnexcused;
              const isAtLimit = unexcused === semesterMaxUnexcused;
              const isApproaching =
                semesterMaxUnexcused > 1 &&
                unexcused === semesterMaxUnexcused - 1;

              const rowBg = isExceeded
                ? 'bg-red-50/40 hover:bg-red-50/60'
                : isAtLimit
                ? 'bg-amber-50/40 hover:bg-amber-50/60'
                : 'hover:bg-slate-50/60';

              return (
                <div
                  key={student.id}
                  className={`p-4 sm:px-5 sm:py-4 transition-colors space-y-3 ${rowBg}`}
                >
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                    <div className="flex items-baseline gap-2.5 min-w-0">
                      <span className="text-xs font-mono tabular-nums text-slate-400 w-5 shrink-0">
                        {String(index + 1).padStart(2, '0')}
                      </span>
                      <div className="min-w-0">
                        <div className="text-sm font-semibold text-slate-900 truncate">
                          {student.fullName}
                        </div>
                        <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs mt-0.5">
                          <span className="font-mono tabular-nums text-slate-500">
                            ID {student.studentNo}
                          </span>
                          <span className="text-slate-300" aria-hidden="true">
                            ·
                          </span>
                          {isExceeded ? (
                            <span className="inline-flex items-center gap-1 font-semibold text-red-700 tabular-nums">
                              <AlertTriangle
                                className="w-3.5 h-3.5 shrink-0"
                                aria-hidden="true"
                              />
                              <span>
                                Semester Unexcused: {unexcused}/{semesterMaxUnexcused} — Exceeded Limit
                              </span>
                            </span>
                          ) : isAtLimit ? (
                            <span className="inline-flex items-center gap-1 font-semibold text-amber-800 tabular-nums">
                              <AlertTriangle
                                className="w-3.5 h-3.5 shrink-0"
                                aria-hidden="true"
                              />
                              <span>
                                Semester Unexcused: {unexcused}/{semesterMaxUnexcused} — At Final Limit
                              </span>
                            </span>
                          ) : isApproaching ? (
                            <span className="inline-flex items-center gap-1 font-medium text-amber-700 tabular-nums">
                              <AlertTriangle
                                className="w-3.5 h-3.5 shrink-0"
                                aria-hidden="true"
                              />
                              <span>
                                Semester Unexcused: {unexcused}/{semesterMaxUnexcused} — 1 Remaining
                              </span>
                            </span>
                          ) : (
                            <span className="text-slate-500 tabular-nums">
                              Semester Unexcused: {unexcused}/{semesterMaxUnexcused}
                            </span>
                          )}
                          {semStats.excusedCount > 0 && (
                            <>
                              <span className="text-slate-300" aria-hidden="true">
                                ·
                              </span>
                              <span className="text-slate-500 tabular-nums">
                                {semStats.excusedCount} Excused (excluded)
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <div
                      role="radiogroup"
                      aria-label={`Attendance status for ${student.fullName}`}
                      className="flex flex-wrap gap-1.5 shrink-0"
                    >
                      {STUDENT_ATTENDANCE_STATUSES.map((status) => {
                        const isActive = record.status === status;
                        const { icon: Icon, activeClass, idleHover } =
                          getStatusVisuals(status);
                        return (
                          <button
                            key={status}
                            type="button"
                            role="radio"
                            aria-checked={isActive}
                            onClick={() =>
                              onStudentChange(student.id, { ...record, status })
                            }
                            className={`inline-flex items-center gap-1.5 px-3 py-2 min-h-[40px] sm:min-h-[36px] text-xs font-medium rounded-md border transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-navy-800 ${
                              isActive
                                ? activeClass
                                : `bg-white text-slate-700 border-slate-200 ${idleHover}`
                            }`}
                          >
                            <Icon
                              className="w-3.5 h-3.5 shrink-0"
                              aria-hidden="true"
                            />
                            <span>{status}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="sm:pl-7">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-1.5 sm:gap-3">
                      <label
                        htmlFor={`remarks-${student.id}`}
                        className="text-xs font-medium text-slate-500 shrink-0 sm:w-16"
                      >
                        Remarks
                      </label>
                      <input
                        id={`remarks-${student.id}`}
                        type="text"
                        value={record.remarks}
                        onChange={(e) =>
                          onStudentChange(student.id, {
                            ...record,
                            remarks: e.target.value,
                          })
                        }
                        placeholder="e.g., Called in sick at 4 PM"
                        className="w-full px-3 py-1.5 text-sm text-slate-900 bg-white border border-slate-200 rounded-md placeholder:text-slate-400 focus:outline-none focus:border-navy-700 focus:ring-1 focus:ring-navy-700 transition-colors"
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
};
