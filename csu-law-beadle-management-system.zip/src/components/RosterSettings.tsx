import React, { useRef, useState } from 'react';
import {
  Plus,
  Trash2,
  RotateCcw,
  Check,
  FileUp,
  FileSpreadsheet,
  Download,
  X,
  AlertCircle,
} from 'lucide-react';
import { CourseConfig, Student } from '../types';
import { ParsedStudentRow, parseRosterDocument } from '../utils/rosterParser';

interface RosterSettingsProps {
  config: CourseConfig;
  onConfigChange: (next: CourseConfig) => void;
  students: Student[];
  onStudentsChange: (next: Student[]) => void;
  onResetDemoData: () => void;
}

export const RosterSettings: React.FC<RosterSettingsProps> = ({
  config,
  onConfigChange,
  students,
  onStudentsChange,
  onResetDemoData,
}) => {
  const [newName, setNewName] = useState('');
  const [newStudentNo, setNewStudentNo] = useState('');
  const [confirmReset, setConfirmReset] = useState(false);

  // Document upload / parse state
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isParsing, setIsParsing] = useState(false);
  const [parseError, setParseError] = useState<string | null>(null);
  const [importSuccess, setImportSuccess] = useState<string | null>(null);
  const [parsedFileName, setParsedFileName] = useState<string>('');
  const [parsedRows, setParsedRows] = useState<ParsedStudentRow[] | null>(null);

  const handleAddStudent = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = newName.trim();
    if (!trimmedName) return;
    const student: Student = {
      id: `stu-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      fullName: trimmedName,
      studentNo:
        newStudentNo.trim() ||
        `2026-${String(students.length + 101).padStart(4, '0')}`,
    };
    onStudentsChange([...students, student]);
    setNewName('');
    setNewStudentNo('');
  };

  const handleUpdateStudent = (
    id: string,
    field: 'fullName' | 'studentNo',
    value: string
  ) => {
    onStudentsChange(
      students.map((s) => (s.id === id ? { ...s, [field]: value } : s))
    );
  };

  const handleRemoveStudent = (id: string) => {
    onStudentsChange(students.filter((s) => s.id !== id));
  };

  const handleRosterFile = async (file: File | undefined) => {
    if (!file) return;
    setParseError(null);
    setImportSuccess(null);
    setIsParsing(true);
    try {
      const rows = await parseRosterDocument(file);
      if (rows.length === 0) {
        setParseError(
          `No student entries could be extracted from "${file.name}". Ensure the document lists student names (and optional ID numbers) in rows or lines.`
        );
        setParsedRows(null);
      } else {
        setParsedFileName(file.name);
        setParsedRows(rows);
      }
    } catch (err) {
      setParseError(
        err instanceof Error
          ? err.message
          : 'Failed to parse roster document.'
      );
      setParsedRows(null);
    } finally {
      setIsParsing(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const toggleParsedRow = (tempId: string) => {
    if (!parsedRows) return;
    setParsedRows(
      parsedRows.map((r) =>
        r.tempId === tempId ? { ...r, selected: !r.selected } : r
      )
    );
  };

  const updateParsedRow = (
    tempId: string,
    field: 'fullName' | 'studentNo',
    value: string
  ) => {
    if (!parsedRows) return;
    setParsedRows(
      parsedRows.map((r) =>
        r.tempId === tempId ? { ...r, [field]: value } : r
      )
    );
  };

  const handleConfirmImport = (mode: 'replace' | 'append') => {
    if (!parsedRows) return;
    const selected = parsedRows.filter((r) => r.selected && r.fullName.trim());
    if (selected.length === 0) return;

    const toStudents: Student[] = selected.map((r, idx) => ({
      id: `stu-${Date.now()}-${idx}-${Math.random().toString(36).slice(2, 6)}`,
      fullName: r.fullName.trim(),
      studentNo: r.studentNo.trim(),
    }));

    if (mode === 'replace') {
      onStudentsChange(toStudents);
      setImportSuccess(
        `Replaced roster with ${toStudents.length} students from "${parsedFileName}".`
      );
    } else {
      const existingNames = new Set(
        students.map((s) => s.fullName.trim().toLowerCase())
      );
      const existingIds = new Set(
        students.map((s) => s.studentNo.trim().toLowerCase())
      );
      const newOnes = toStudents.filter(
        (s) =>
          !existingNames.has(s.fullName.toLowerCase()) &&
          !existingIds.has(s.studentNo.toLowerCase())
      );
      onStudentsChange([...students, ...newOnes]);
      setImportSuccess(
        `Added ${newOnes.length} new students (${toStudents.length - newOnes.length} duplicates skipped).`
      );
    }

    setParsedRows(null);
    setParsedFileName('');
  };

  const handleDownloadSampleCsv = () => {
    const csvContent = [
      'Student No,Full Name',
      '2024-0104,"Alvarez, Gabriel M."',
      '2024-0112,"Bautista, Maria Clarissa R."',
      '2024-0129,"Delos Santos, Paolo J."',
      '2024-0137,"Mendoza, Katrina L."',
      '2024-0145,"Villanueva, Rafael C."',
    ].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'sample_class_roster.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const selectedParsedCount = parsedRows
    ? parsedRows.filter((r) => r.selected && r.fullName.trim()).length
    : 0;

  return (
    <div className="space-y-6">
      {/* Class Specifications & Institutional Header */}
      <section className="bg-white border border-slate-200 rounded-lg">
        <div className="px-5 py-4 border-b border-slate-200">
          <h2 className="text-base font-semibold text-navy-900">
            Class Specifications &amp; Academic Details
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Update subject name, units, schedule, professor, and institutional details for your workspace and monthly Dean reports
          </p>
        </div>

        <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label
              htmlFor="cfg-course"
              className="block text-xs font-medium text-slate-600 mb-1"
            >
              Subject / Course Name
            </label>
            <input
              id="cfg-course"
              type="text"
              value={config.courseTitle}
              onChange={(e) =>
                onConfigChange({ ...config, courseTitle: e.target.value })
              }
              placeholder="e.g., Laws on Local Government"
              className="w-full px-3 py-2 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-md focus:bg-white focus:outline-none focus:border-navy-700"
            />
          </div>

          <div>
            <label
              htmlFor="cfg-units"
              className="block text-xs font-medium text-slate-600 mb-1"
            >
              Number of Units
            </label>
            <input
              id="cfg-units"
              type="text"
              value={config.units}
              onChange={(e) =>
                onConfigChange({ ...config, units: e.target.value })
              }
              placeholder="e.g., 2 Units"
              className="w-full px-3 py-2 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-md focus:bg-white focus:outline-none focus:border-navy-700"
            />
          </div>

          <div>
            <label
              htmlFor="cfg-schedule"
              className="block text-xs font-medium text-slate-600 mb-1"
            >
              Class Schedule
            </label>
            <input
              id="cfg-schedule"
              type="text"
              value={config.scheduleLabel}
              onChange={(e) =>
                onConfigChange({ ...config, scheduleLabel: e.target.value })
              }
              placeholder="e.g., Wednesdays, 6:00 PM – 8:00 PM PHT"
              className="w-full px-3 py-2 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-md focus:bg-white focus:outline-none focus:border-navy-700"
            />
          </div>

          <div>
            <label
              htmlFor="cfg-professor"
              className="block text-xs font-medium text-slate-600 mb-1"
            >
              Professor Name
            </label>
            <input
              id="cfg-professor"
              type="text"
              value={config.professorName}
              onChange={(e) =>
                onConfigChange({ ...config, professorName: e.target.value })
              }
              placeholder="e.g., Atty. Roberto V. Domingo, LL.M."
              className="w-full px-3 py-2 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-md focus:bg-white focus:outline-none focus:border-navy-700"
            />
          </div>

          <div>
            <label
              htmlFor="cfg-beadle"
              className="block text-xs font-medium text-slate-600 mb-1"
            >
              Class Beadle Name
            </label>
            <input
              id="cfg-beadle"
              type="text"
              value={config.beadleName}
              onChange={(e) =>
                onConfigChange({ ...config, beadleName: e.target.value })
              }
              className="w-full px-3 py-2 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-md focus:bg-white focus:outline-none focus:border-navy-700"
            />
          </div>

          <div>
            <label
              htmlFor="cfg-threshold"
              className="block text-xs font-medium text-slate-600 mb-1"
            >
              Max Unexcused Absences per Semester
            </label>
            <input
              id="cfg-threshold"
              type="number"
              min={1}
              max={15}
              value={config.semesterMaxUnexcused}
              onChange={(e) =>
                onConfigChange({
                  ...config,
                  semesterMaxUnexcused: Math.max(1, Number(e.target.value) || 1),
                })
              }
              className="w-full px-3 py-2 text-sm font-mono tabular-nums text-slate-900 bg-slate-50 border border-slate-200 rounded-md focus:bg-white focus:outline-none focus:border-navy-700"
            />
            <p className="text-[11px] text-slate-500 mt-1">
              1st Sem: Aug–Dec · 2nd Sem: Jan–May · Excused absences are excluded
            </p>
          </div>

          <div>
            <label
              htmlFor="cfg-university"
              className="block text-xs font-medium text-slate-600 mb-1"
            >
              University &amp; Campus
            </label>
            <input
              id="cfg-university"
              type="text"
              value={config.university}
              onChange={(e) =>
                onConfigChange({ ...config, university: e.target.value })
              }
              className="w-full px-3 py-2 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-md focus:bg-white focus:outline-none focus:border-navy-700"
            />
          </div>

          <div>
            <label
              htmlFor="cfg-recipient"
              className="block text-xs font-medium text-slate-600 mb-1"
            >
              Dean&rsquo;s Office (Report Recipient)
            </label>
            <input
              id="cfg-recipient"
              type="text"
              value={config.recipientOffice}
              onChange={(e) =>
                onConfigChange({ ...config, recipientOffice: e.target.value })
              }
              className="w-full px-3 py-2 text-sm text-slate-900 bg-slate-50 border border-slate-200 rounded-md focus:bg-white focus:outline-none focus:border-navy-700"
            />
          </div>
        </div>
      </section>

      {/* Student Roster Management & Document Import */}
      <section className="bg-white border border-slate-200 rounded-lg">
        <div className="px-5 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold text-navy-900">
              Enrolled Student Roster
            </h2>
            <p className="text-xs text-slate-500 mt-0.5 tabular-nums">
              {students.length} students · Upload a class list document or edit entries manually
            </p>
          </div>
          <button
            type="button"
            onClick={handleDownloadSampleCsv}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-navy-900 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors whitespace-nowrap shrink-0"
          >
            <Download className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Sample CSV</span>
          </button>
        </div>

        {/* Upload & Parse Roster Document Dropzone */}
        <div className="p-5 border-b border-slate-200 space-y-4">
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setIsDragging(false);
              void handleRosterFile(e.dataTransfer.files?.[0]);
            }}
            className={`border border-dashed rounded-lg p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 transition-colors ${
              isDragging
                ? 'border-navy-700 bg-navy-50'
                : 'border-slate-300 bg-slate-50/70 hover:border-slate-400'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv,.tsv,.txt,.xlsx,.xls,.docx,.pdf"
              onChange={(e) => void handleRosterFile(e.target.files?.[0])}
              className="sr-only"
              id="roster-doc-upload"
            />
            <div className="flex items-start gap-3">
              <FileSpreadsheet
                className="w-5 h-5 text-navy-800 mt-0.5 shrink-0"
                aria-hidden="true"
              />
              <div>
                <div className="text-sm font-semibold text-slate-900">
                  Import Class Roster Document
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  Upload Excel (.xlsx, .xls), CSV, Word (.docx), PDF (.pdf), or TXT files. Columns or lines with names and student IDs are parsed automatically.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={isParsing}
              className="inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-navy-900 rounded-md hover:bg-navy-800 disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
            >
              <FileUp className="w-4 h-4" aria-hidden="true" />
              <span>{isParsing ? 'Parsing Document...' : 'Upload Document'}</span>
            </button>
          </div>

          {parseError && (
            <div
              role="alert"
              className="px-3.5 py-2.5 text-xs text-red-800 bg-red-50 border border-red-200 rounded-md flex items-center gap-2"
            >
              <AlertCircle className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>{parseError}</span>
            </div>
          )}

          {importSuccess && (
            <div
              role="status"
              className="px-3.5 py-2.5 text-xs text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-md flex items-center justify-between gap-2"
            >
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{importSuccess}</span>
              </div>
              <button
                type="button"
                onClick={() => setImportSuccess(null)}
                aria-label="Dismiss message"
                className="text-emerald-700 hover:text-emerald-900"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Parsed Roster Preview & Confirm */}
          {parsedRows && (
            <div className="border border-navy-200 rounded-lg bg-navy-50/40 overflow-hidden">
              <div className="px-4 py-3 border-b border-navy-200 bg-white flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="text-xs font-bold text-navy-900">
                    Parsed Preview: {parsedFileName}
                  </div>
                  <div className="text-[11px] text-slate-600 tabular-nums">
                    {selectedParsedCount} of {parsedRows.length} detected entries selected · Review or edit before importing
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setParsedRows(null);
                    setParsedFileName('');
                  }}
                  className="inline-flex items-center gap-1 px-2.5 py-1 text-xs text-slate-600 hover:text-slate-900 rounded hover:bg-slate-100"
                >
                  <X className="w-3.5 h-3.5" />
                  <span>Cancel</span>
                </button>
              </div>

              <div className="max-h-72 overflow-y-auto divide-y divide-slate-200 bg-white">
                {parsedRows.map((row) => (
                  <div
                    key={row.tempId}
                    className="px-4 py-2.5 flex flex-col sm:flex-row sm:items-center gap-2.5"
                  >
                    <input
                      type="checkbox"
                      checked={row.selected}
                      onChange={() => toggleParsedRow(row.tempId)}
                      aria-label={`Include ${row.fullName}`}
                      className="w-4 h-4 accent-navy-900 shrink-0"
                    />
                    <input
                      type="text"
                      value={row.fullName}
                      onChange={(e) =>
                        updateParsedRow(row.tempId, 'fullName', e.target.value)
                      }
                      aria-label="Parsed student name"
                      className="flex-1 px-2.5 py-1 text-xs font-medium text-slate-900 bg-slate-50 border border-slate-200 rounded focus:bg-white focus:outline-none focus:border-navy-700"
                    />
                    <input
                      type="text"
                      value={row.studentNo}
                      onChange={(e) =>
                        updateParsedRow(row.tempId, 'studentNo', e.target.value)
                      }
                      aria-label="Parsed student number"
                      className="sm:w-32 px-2.5 py-1 text-xs font-mono tabular-nums text-slate-700 bg-slate-50 border border-slate-200 rounded focus:bg-white focus:outline-none focus:border-navy-700"
                    />
                  </div>
                ))}
              </div>

              <div className="px-4 py-3 border-t border-navy-200 bg-slate-50 flex flex-wrap items-center justify-end gap-2.5">
                <button
                  type="button"
                  disabled={selectedParsedCount === 0}
                  onClick={() => handleConfirmImport('append')}
                  className="px-3.5 py-2 text-xs font-semibold text-navy-900 bg-white border border-slate-300 rounded-md hover:bg-slate-100 disabled:opacity-40 transition-colors"
                >
                  Append to Existing ({selectedParsedCount})
                </button>
                <button
                  type="button"
                  disabled={selectedParsedCount === 0}
                  onClick={() => handleConfirmImport('replace')}
                  className="px-3.5 py-2 text-xs font-semibold text-white bg-navy-900 rounded-md hover:bg-navy-800 disabled:opacity-40 transition-colors"
                >
                  Replace Current Roster ({selectedParsedCount})
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Manual Single Student Add */}
        <form
          onSubmit={handleAddStudent}
          className="p-5 border-b border-slate-200 bg-slate-50/70 flex flex-col sm:flex-row gap-3 items-stretch sm:items-end"
        >
          <div className="flex-1">
            <label
              htmlFor="new-student-name"
              className="block text-xs font-medium text-slate-600 mb-1"
            >
              Add Student Manually (Last, First M.I.)
            </label>
            <input
              id="new-student-name"
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="e.g., Soriano, Patricia D."
              className="w-full px-3 py-2 text-sm text-slate-900 bg-white border border-slate-200 rounded-md focus:outline-none focus:border-navy-700"
            />
          </div>

          <div className="sm:w-44">
            <label
              htmlFor="new-student-no"
              className="block text-xs font-medium text-slate-600 mb-1"
            >
              Student Number
            </label>
            <input
              id="new-student-no"
              type="text"
              value={newStudentNo}
              onChange={(e) => setNewStudentNo(e.target.value)}
              placeholder="e.g., 2024-0152"
              className="w-full px-3 py-2 text-sm font-mono tabular-nums text-slate-900 bg-white border border-slate-200 rounded-md focus:outline-none focus:border-navy-700"
            />
          </div>

          <button
            type="submit"
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-navy-900 rounded-md hover:bg-navy-800 transition-colors whitespace-nowrap shrink-0 min-h-[38px]"
          >
            <Plus className="w-4 h-4" aria-hidden="true" />
            <span>Add Student</span>
          </button>
        </form>

        <div className="divide-y divide-slate-200">
          {students.map((student, idx) => (
            <div
              key={student.id}
              className="p-4 sm:px-5 flex flex-col sm:flex-row sm:items-center gap-3"
            >
              <span className="text-xs font-mono tabular-nums text-slate-400 w-6 shrink-0">
                {String(idx + 1).padStart(2, '0')}
              </span>
              <input
                type="text"
                value={student.fullName}
                aria-label={`Name for student ${idx + 1}`}
                onChange={(e) =>
                  handleUpdateStudent(student.id, 'fullName', e.target.value)
                }
                className="flex-1 px-3 py-1.5 text-sm font-medium text-slate-900 bg-slate-50 border border-slate-200 rounded focus:bg-white focus:outline-none focus:border-navy-700"
              />
              <input
                type="text"
                value={student.studentNo}
                aria-label={`Student number for ${student.fullName}`}
                onChange={(e) =>
                  handleUpdateStudent(student.id, 'studentNo', e.target.value)
                }
                className="sm:w-36 px-3 py-1.5 text-sm font-mono tabular-nums text-slate-700 bg-slate-50 border border-slate-200 rounded focus:bg-white focus:outline-none focus:border-navy-700"
              />
              <button
                type="button"
                onClick={() => handleRemoveStudent(student.id)}
                aria-label={`Remove ${student.fullName}`}
                className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-red-700 hover:bg-red-50 border border-slate-200 rounded transition-colors shrink-0"
              >
                <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Remove</span>
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Local Storage Data Management */}
      <section className="bg-white border border-slate-200 rounded-lg p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h3 className="text-sm font-semibold text-slate-900">
            Browser Local Storage
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            All attendance logs, narratives, and photos are stored locally in this browser.
          </p>
        </div>

        {!confirmReset ? (
          <button
            type="button"
            onClick={() => setConfirmReset(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors whitespace-nowrap shrink-0"
          >
            <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Restore Sample Data</span>
          </button>
        ) : (
          <div className="flex items-center gap-2 shrink-0">
            <span className="text-xs text-red-700 font-medium">
              Overwrite current logs?
            </span>
            <button
              type="button"
              onClick={() => {
                onResetDemoData();
                setConfirmReset(false);
              }}
              className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-red-700 hover:bg-red-800 rounded-md transition-colors"
            >
              <Check className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Confirm</span>
            </button>
            <button
              type="button"
              onClick={() => setConfirmReset(false)}
              className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-100 rounded-md"
            >
              Cancel
            </button>
          </div>
        )}
      </section>
    </div>
  );
};
